LVGL SDK readme.txt
Please contact LVGL company to request SDK resource.