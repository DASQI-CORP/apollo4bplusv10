


/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
// #include "am_devices_tma525.h"
#include "i2c.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable                                                            */
/*                                                                            */
/******************************************************************************/
am_hal_iom_config_t g_i2c_Cfg = 
{
	.eInterfaceMode = AM_HAL_IOM_I2C_MODE,
	.ui32ClockFreq = AM_HAL_IOM_400KHZ,
	.ui32NBTxnBufLength = 0,
	.pNBTxnBuf = NULL,
};
/******************************************************************************/
/*                                                                            */
/* i2c_init                                                                   */
/*                                                                            */
/******************************************************************************/
int i2c_init(uint32_t ui32Module, am_hal_iom_config_t *psIOMSettings, void **ppIomHandle)
{
		if(ui32Module>AM_REG_IOM_NUM_MODULES) // 8
		{
			return DEVICES_I2C_STATUS_ERROR;
		}
		//
		// Configure the IOM pins.
		//
		am_bsp_iom_pins_enable(ui32Module, AM_HAL_IOM_I2C_MODE);

		//
		// Initialize the IOM instance.
		// Enable power to the IOM instance.
		// Configure the IOM for Serial operation during initialization.
		// Enable the IOM.
		// HAL Success return is 0
		//
		void *iomHandle;
		if(
				am_hal_iom_initialize(ui32Module, &iomHandle) ||
				am_hal_iom_power_ctrl(iomHandle, AM_HAL_SYSCTRL_WAKE, false) ||
				am_hal_iom_configure(iomHandle, psIOMSettings) ||
				am_hal_iom_enable(iomHandle)
		)
		{
				return DEVICES_I2C_STATUS_ERROR;
		}
		else
		{
			*ppIomHandle=iomHandle;
		}

		return DEVICES_I2C_STATUS_SUCCESS;
}
/******************************************************************************/
/*                                                                            */
/* i2c_read                                                                   */
/*                                                                            */
/******************************************************************************/
int i2c_read(void *handle, uint32_t ui32BusAddress, uint32_t *pBuf, uint32_t size)
{
		am_hal_iom_transfer_t       Transaction;

		Transaction.ui8Priority     = 1;
		Transaction.ui32InstrLen    = 0;
		#if defined(AM_PART_APOLLO4B) || defined(AM_PART_APOLLO4P) || defined(AM_PART_APOLLO4L)
		Transaction.ui64Instr       = 0;
		#else
		Transaction.ui32Instr       = 0;
		#endif
		Transaction.eDirection      = AM_HAL_IOM_RX;
		Transaction.ui32NumBytes    = size;
		Transaction.pui32RxBuffer   = pBuf;
		Transaction.bContinue       = false;
		Transaction.ui8RepeatCount  = 0;
		Transaction.ui32PauseCondition = 0;
		Transaction.ui32StatusSetClr = 0;

		Transaction.uPeerInfo.ui32I2CDevAddr = ui32BusAddress;
		if (am_hal_iom_blocking_transfer(handle, &Transaction) != AM_HAL_STATUS_SUCCESS)
		{
			return -1;
		}

		return DEVICES_I2C_STATUS_SUCCESS;
}
/******************************************************************************/
/*                                                                            */
/* i2c_write                                                                  */
/*                                                                            */
/******************************************************************************/
int i2c_write(void *handle, uint32_t ui32BusAddress, uint32_t *pBuf, uint32_t size)
{
		am_hal_iom_transfer_t       Transaction;

		Transaction.ui8Priority     = 1;
		Transaction.ui32InstrLen    = 0;
		#if defined(AM_PART_APOLLO4B) || defined(AM_PART_APOLLO4P) || defined(AM_PART_APOLLO4L)
		Transaction.ui64Instr       = 0;
		#else
		Transaction.ui32Instr       = 0;    //IOSOFFSET_WRITE_CMD;
		#endif
		Transaction.eDirection      = AM_HAL_IOM_TX;
		Transaction.ui32NumBytes    = size;
		Transaction.pui32TxBuffer   = pBuf;
		Transaction.bContinue       = false;
		Transaction.ui8RepeatCount  = 0;
		Transaction.ui32PauseCondition = 0;
		Transaction.ui32StatusSetClr = 0;

		Transaction.uPeerInfo.ui32I2CDevAddr = ui32BusAddress;
		if (am_hal_iom_blocking_transfer(handle, &Transaction) != AM_HAL_STATUS_SUCCESS)
		{
			return DEVICES_I2C_STATUS_ERROR;
		}

		return 0;
}
/******************************************************************************/
/*                                                                            */
/* i2c_master_xfer                                                            */
/*                                                                            */
/******************************************************************************/
int i2c_master_xfer(void *handle, i2c_msg_t *msgs, uint32_t num)
{
		i2c_msg_t *msg;
		int i;
		uint32_t msg_len=0;

		for(i=0; i<num; i++)
		{
				msg=&msgs[i];
		
				if(msg->flags==AM_DEVICES_I2C_RD)
				{
						i2c_read(handle, msg->addr, (uint32_t *)msg->buf, msg->len);
						msg_len+=msg->len;
				}
				else if ( msg->flags == AM_DEVICES_I2C_WR )
				{
						i2c_write(handle, msg->addr, (uint32_t *)msg->buf, msg->len);
						msg_len+=msg->len;
				}
		}

		return msg_len;
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/







