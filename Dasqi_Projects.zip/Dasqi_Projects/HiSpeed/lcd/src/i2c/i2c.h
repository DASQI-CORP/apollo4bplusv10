


#ifndef _I2C_H
#define _I2C_H
/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\main.h"
/******************************************************************************/
/*                                                                            */
/* Global Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
/******************************************************************************/
#define AM_DEVICES_I2C_WR (0x0000)
#define AM_DEVICES_I2C_RD (1u<< 0)
/******************************************************************************/
typedef struct _i2c_msg_t
{
	uint16_t addr;
	uint16_t flags;
	uint16_t len;
	uint8_t *buf;
} i2c_msg_t;
/******************************************************************************/
typedef enum
{
	DEVICES_I2C_STATUS_SUCCESS=0,
	DEVICES_I2C_STATUS_ERROR=-1
} devices_i2c_status_t;
/******************************************************************************/
extern am_hal_iom_config_t g_i2c_Cfg;
/******************************************************************************/
/*                                                                            */
/* Functions                                                                  */
/*                                                                            */
/******************************************************************************/
extern int i2c_init(uint32_t ui32Module, am_hal_iom_config_t *psIOMSettings, void **ppIomHandle);
extern int i2c_read(void *handle, uint32_t ui32BusAddress, uint32_t *pBuf, uint32_t size);
extern int i2c_write(void *handle, uint32_t ui32BusAddress, uint32_t *pBuf, uint32_t size);
extern int i2c_master_xfer(void *handle, i2c_msg_t *msgs, uint32_t num);
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
#endif








