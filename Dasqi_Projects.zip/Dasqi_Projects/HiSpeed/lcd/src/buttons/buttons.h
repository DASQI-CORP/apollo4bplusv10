



#ifndef _BUTTONS_H
#define _BUTTONS_H
/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\main.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
#define BUTTON_OK     18
#define BUTTON_LEFT   19
#define BUTTON_RIGHT  22
#define BUTTON_UP     23
#define BUTTON_DOWN   24
/******************************************************************************/
extern bool bBtn_Ok_Pre;
extern bool bBtn_Left_Pre;
extern bool bBtn_Right_Pre;
extern bool bBtn_Up_Pre;
extern bool bBtn_Down_Pre;
/******************************************************************************/
/*                                                                            */
/* Functions                                                                  */
/*                                                                            */
/******************************************************************************/
extern void TASK_Button(void);
extern bool Btn_Ok(void);
extern bool Btn_Left(void);
extern bool Btn_Right(void);
extern bool Btn_Up(void);
extern bool Btn_Down(void);
extern void init_button(void);
/******************************************************************************/
#endif




