







/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "buttons.h"
#include "..\wave\wave.h"
#include "..\i2s\i2s.h"
#include "..\sdcard\sdcard.h"
/******************************************************************************/
bool bBtn_Ok_Pre;
bool bBtn_Left_Pre;
bool bBtn_Right_Pre;
bool bBtn_Up_Pre;
bool bBtn_Down_Pre;
/******************************************************************************/
/*                                                                            */
/* TASK Button                                                                */
/*                                                                            */
/******************************************************************************/
void TASK_Button(void)
{
		static bool init=true;
		static volatile uint32_t t0;

		if(init)
		{
			init=false;
			t0=msec;
			init_button();
		}
		else
		{
			if((msec-t0)>19)
			{
				t0=msec;

				#if 0
				if(Btn_Ok())am_util_stdio_printf("OK\n");
				if(Btn_Left())am_util_stdio_printf("Left\n");
				if(Btn_Right())am_util_stdio_printf("Right\n");
				if(Btn_Up())am_util_stdio_printf("Up\n");
				if(Btn_Down())am_util_stdio_printf("Down\n");
				#endif

				#if 1
				if(Btn_Ok())
				{ 
					if(bStopSong==false)bStopSong=true;else bStopSong=false; 
				}

				if(Btn_Left()||Btn_Right()||Btn_Up()||Btn_Down())
				{
					bNextSongBtnPressed=true;
				}

				if(iSDCARD_Error==0)
				{
					if(bStopSong==true)
					{
						if(bI2S_IRQ_Enabled==true)
						{
							NVIC_DisableIRQ(i2s_interrupts[I2S_MODULE_0]);
							bI2S_IRQ_Enabled=false;
						}
					}
					else
					{
						if(bI2S_IRQ_Enabled==false)
						{
							NVIC_EnableIRQ(i2s_interrupts[I2S_MODULE_0]);
							bI2S_IRQ_Enabled=true;
						}
					}
				}
				#endif
			}
		}
}
/******************************************************************************/
/*                                                                            */
/* Btn Ok                                                                     */
/*                                                                            */
/******************************************************************************/
bool Btn_Ok(void)
{
		bool bBtn_Ok;
		bool bBtn_Chg;
		bool bBtn_Pressed=false;

		if(am_hal_gpio_input_read(BUTTON_OK))bBtn_Ok=true;else bBtn_Ok=false;
		bBtn_Chg=bBtn_Ok^bBtn_Ok_Pre;
		if((bBtn_Chg==true)&&(bBtn_Ok_Pre==true))
		{
			bBtn_Pressed=true;
		}
		bBtn_Ok_Pre=bBtn_Ok;

		return bBtn_Pressed;
}

/******************************************************************************/
/*                                                                            */
/* Btn Left                                                                   */
/*                                                                            */
/******************************************************************************/
bool Btn_Left(void)
{
		bool bBtn_Left;
		bool bBtn_Chg;
		bool bBtn_Pressed=false;

		if(am_hal_gpio_input_read(BUTTON_LEFT))bBtn_Left=true;else bBtn_Left=false;
		bBtn_Chg=bBtn_Left^bBtn_Left_Pre;
		if((bBtn_Chg==true)&&(bBtn_Left_Pre==true))
		{
			bBtn_Pressed=true;
		}
		bBtn_Left_Pre=bBtn_Left;

		return bBtn_Pressed;
}
/******************************************************************************/
/*                                                                            */
/* Btn Right                                                                  */
/*                                                                            */
/******************************************************************************/
bool Btn_Right(void)
{
		bool bBtn_Right;
		bool bBtn_Chg;
		bool bBtn_Pressed=false;

		if(am_hal_gpio_input_read(BUTTON_RIGHT))bBtn_Right=true;else bBtn_Right=false;
		bBtn_Chg=bBtn_Right^bBtn_Right_Pre;
		if((bBtn_Chg==true)&&(bBtn_Right_Pre==true))
		{
			bBtn_Pressed=true;
		}
		bBtn_Right_Pre=bBtn_Right;

		return bBtn_Pressed;
}
/******************************************************************************/
/*                                                                            */
/* Btn Up                                                                     */
/*                                                                            */
/******************************************************************************/
bool Btn_Up(void)
{
		bool bBtn_Up;
		bool bBtn_Chg;
		bool bBtn_Pressed=false;

		if(am_hal_gpio_input_read(BUTTON_UP))bBtn_Up=true;else bBtn_Up=false;
		bBtn_Chg=bBtn_Up^bBtn_Up_Pre;
		if((bBtn_Chg==true)&&(bBtn_Up_Pre==true))
		{
			bBtn_Pressed=true;
		}
		bBtn_Up_Pre=bBtn_Up;

		return bBtn_Pressed;
}
/******************************************************************************/
/*                                                                            */
/* Btn Down                                                                   */
/*                                                                            */
/******************************************************************************/
bool Btn_Down(void)
{
		bool bBtn_Down;
		bool bBtn_Chg;
		bool bBtn_Pressed=false;

		if(am_hal_gpio_input_read(BUTTON_DOWN))bBtn_Down=true;else bBtn_Down=false;
		bBtn_Chg=bBtn_Down^bBtn_Down_Pre;
		if((bBtn_Chg==true)&&(bBtn_Down_Pre==true))
		{
			bBtn_Pressed=true;
		}
		bBtn_Down_Pre=bBtn_Down;

		return bBtn_Pressed;
}
/******************************************************************************/
/*                                                                            */
/* init button                                                                */
/*                                                                            */
/******************************************************************************/
void init_button(void)
{
		am_hal_gpio_pinconfig(BUTTON_OK, am_hal_gpio_pincfg_input);
		if(am_hal_gpio_input_read(BUTTON_OK))bBtn_Ok_Pre=true;else bBtn_Ok_Pre=false;

		am_hal_gpio_pinconfig(BUTTON_LEFT, am_hal_gpio_pincfg_input);
		if(am_hal_gpio_input_read(BUTTON_LEFT))bBtn_Left_Pre=true;else bBtn_Left_Pre=false;

		am_hal_gpio_pinconfig(BUTTON_RIGHT, am_hal_gpio_pincfg_input);
		if(am_hal_gpio_input_read(BUTTON_RIGHT))bBtn_Right_Pre=true;else bBtn_Right_Pre=false;

		am_hal_gpio_pinconfig(BUTTON_UP, am_hal_gpio_pincfg_input);
		if(am_hal_gpio_input_read(BUTTON_UP))bBtn_Up_Pre=true;else bBtn_Up_Pre=false;

		am_hal_gpio_pinconfig(BUTTON_DOWN, am_hal_gpio_pincfg_input);
		if(am_hal_gpio_input_read(BUTTON_DOWN))bBtn_Down_Pre=true;else bBtn_Down_Pre=false;
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/





