


#ifndef _LCD_TEST_H
#define _LCD_TEST_H
/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\main.h"
/******************************************************************************/
/*                                                                            */
/* Global Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
#define _BLACK 0
#define _RED   1
#define _GREEN 2
#define _BLUE  3
#define _WHITE 4
/******************************************************************************/
/*                                                                            */
/* Functions                                                                  */
/*                                                                            */
/******************************************************************************/
extern void Blank_V(uint8_t rgb);
extern void Blank_H(uint8_t rgb);
extern void display_line_h(uint8_t rgb, uint32_t y);
extern void display_line_v(uint8_t rgb, uint32_t x);
extern void display_window(uint8_t rgb, uint32_t x0, uint32_t x1, uint32_t y0, uint32_t y1);
extern void toggle_display(void);
extern void toggle_display_color(void);
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
#endif



