





/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\main.h"
#include "lcd.h"
#include "lcd_test.h"
/******************************************************************************/
#include "..\stimer.h"
#include "..\sh8601\sh8601.h"
#include "..\am_devices_nemadc_rm67162\am_devices_nemadc_rm67162.h"
#include "..\lvgl\porting\lv_port_disp.h"
#include "..\lvgl\porting\lv_port_indev.h"
#include "..\lvgl\lv_demo\lv_demo.h"
/******************************************************************************/
/******************************************************************************/
#include "nema_core.h"
#include "nema_font.h"
#include "nema_dc_hal.h"
#include "nema_dc.h"
#include "nema_easing.h"
#include "nema_transitions.h"
#include "nema_event.h"
#include "nema_utils.h"
#include "nema_graphics.h"
/******************************************************************************/
/*                                                                            */
/* Global Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
uint32_t fps_start_time;
uint32_t fps_stop_time;
/******************************************************************************/
/*                                                                            */
/* Reset Lcd                                                                  */
/*                                                                            */
/******************************************************************************/
void reset_lcd(void)
{
			//
			// Set LCD_RESET_PIN Hi
			//
			am_hal_gpio_pinconfig(LCD_RST_PIN, am_hal_gpio_pincfg_output);
			am_hal_gpio_state_write(LCD_RST_PIN, AM_HAL_GPIO_OUTPUT_TRISTATE_DISABLE);
			am_hal_gpio_state_write(LCD_RST_PIN, AM_HAL_GPIO_OUTPUT_SET);
			//
			// Reset Touch
			//
			am_util_delay_ms(1);
			am_hal_gpio_state_write(LCD_RST_PIN, AM_HAL_GPIO_OUTPUT_CLEAR);
			am_util_delay_ms(1);
			am_hal_gpio_state_write(LCD_RST_PIN, AM_HAL_GPIO_OUTPUT_SET);
			am_util_delay_ms(6);
}
/******************************************************************************/
/*                                                                            */
/* fps                                                                        */
/*                                                                            */
/******************************************************************************/
void fps(void)
{
		static int frame = 0;

		if(++frame>99) 
		{
			fps_stop_time = msec;
			am_util_stdio_printf("fps: %.02f\n", (100*1000.f)/(fps_stop_time-fps_start_time));
			fps_start_time = fps_stop_time;
			frame=0;
		}
}
/******************************************************************************/
/*                                                                            */
/* Blank_Screen                                                               */
/*                                                                            */
/******************************************************************************/
void Blank_Screen(uint16_t color)
{
		img_obj_t fb;
		fb.stride = nema_stride_size(NEMA_RGB565, 0, XMAX); // stride=2*XMAX
		fb.w = XMAX;
		fb.h = YMAX;
		fb.format = NEMA_RGB565;
		fb.bo = nema_buffer_create(fb.stride*fb.h);
		nema_buffer_map(&fb.bo); // Needless
		#if 0
		am_util_stdio_printf("FB: V:%p P:0x%08x\n", (void *)fb.bo.base_virt, fb.bo.base_phys);
		#endif

		nemadc_layer_t layer= {0};
		layer.sizex = layer.resx = fb.w;
		layer.sizey = layer.resy = fb.h;
		layer.stride = -1;
		layer.format = NEMADC_RGB565;
		layer.blendmode = NEMADC_BL_SRC;
		layer.baseaddr_phys = fb.bo.base_phys;
		layer.baseaddr_virt = fb.bo.base_virt;

		//
		// Enable Layer and set attributes to it, this is a must
		//
		nemadc_set_layer(0, &layer);

		uint16_t *p=(uint16_t*)layer.baseaddr_phys;
		for(uint32_t j=0; j<(layer.resx*layer.resy); j++)
		{
			*p++=color;
		}
		nemadc_send_frame_single();
		nema_buffer_destroy(&fb.bo);
}
/******************************************************************************/
/*                                                                            */
/* init                                                                       */
/*                                                                            */
/******************************************************************************/
void SelfTest(void)
{
		#if 0
		for(;;)
		{
			Blank_Screen(__RED);
			am_util_delay_ms(1000);
			Blank_Screen(__GREEN);
			am_util_delay_ms(1000);
			Blank_Screen(__BLUE);
			am_util_delay_ms(1000);
			Blank_Screen(__YELLOW);
			am_util_delay_ms(1000);
			Blank_Screen(__PURPLE);
			am_util_delay_ms(1000);
			Blank_Screen(__CYAN);
			am_util_delay_ms(1000);
		}
		#endif

		#if 0
		Blank_Screen(__GREEN);
		for(;;)
		{
			am_util_delay_ms(1000);
			send_MIPI_cmd(QSPI_MODE, 0x28, NULL, 0);
			am_util_delay_ms(1000);
			send_MIPI_cmd(QSPI_MODE, 0x29, NULL, 0);
		}
		#endif

		#if 0
		for(;;)
		{
			Blank_Screen(__GREEN);
			fps();
		}
		#endif
}
/******************************************************************************/
/*                                                                            */
/* TASK LCD                                                                   */
/*                                                                            */
/******************************************************************************/
void TASK_LCD(void)
{
		static bool init=false;
		static uint32_t t0;

		if(!init)
		{
			init=true;
			t0=msec;

			fps_start_time=msec;
			fps_stop_time=msec;

			//
			// NEMA Initialize
			//
			nema_init();

			reset_lcd();

			#ifdef USE_MSPI
			sh8601_init(LcdMSPModule);
			NVIC_SetPriority(MSPI2_IRQn, AM_IRQ_PRIORITY_DEFAULT);
			NVIC_EnableIRQ(MSPI2_IRQn);
			#if 0
			am_hal_pwrctrl_periph_enable(AM_HAL_PWRCTRL_PERIPH_MSPI2); // Seems no need
			#endif
			#endif

			#ifdef USE_NEMADC
			nemadc_init();
			//
			// pixel_format:
			// MIPICFG_1RGB565_OPT0,  // NG
			// MIPICFG_2RGB565_OPT0,  // OK
			// MIPICFG_4RGB565_OPT0,  // OK, 4 wire
			// MIPICFG_8RGB565_OPT0,  // NG
			// MIPICFG_16RGB565_OPT0, // OK
			// MIPICFG_32RGB565_OPT0, // NG
			//
			for(int i=0; i<4; i++)
			{
				am_devices_nemadc_rm67162_init(MIPICFG_QSPI | MIPICFG_SPI4, MIPICFG_4RGB565_OPT0, XMAX, YMAX, 0, 0);
			}

			SelfTest();

			#endif

			lv_init();
			lv_port_disp_init();
			lv_port_indev_init();
			lv_demo();
		}
		else
		{
			if((msec-t0)>7)
			{
				t0=msec;
				lv_timer_handler(); 
			}
		}
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/

