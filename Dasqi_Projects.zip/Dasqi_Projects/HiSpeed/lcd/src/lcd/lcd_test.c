



/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "lcd_test.h"
#include "lcd.h"
#include "..\sh8601\sh8601.h"
/******************************************************************************/
/*                                                                            */
/* Blank_V                                                                    */
/*                                                                            */
/******************************************************************************/
void Blank_V(uint8_t rgb)
{
		uint8_t buf[YMAX*2]; // 16bit
		uint8_t c0;
		uint8_t c1;

		switch(rgb)
		{
			case _BLACK: c0=0x00; c1=0x00; break;
			case _RED:   c0=0xF8; c1=0x00; break;
			case _GREEN: c0=0x07; c1=0xE0; break;
			case _BLUE:  c0=0x00; c1=0x1F; break;
			case _WHITE: c0=0xFF; c1=0xFF; break;
		}
		for(uint32_t i=0; i<YMAX; i++)
		{
				buf[i*2+0]=c0;
				buf[i*2+1]=c1;
		}

		lv_area_t area;
		for(uint32_t i=0; i<XMAX; i++)
		{
			area.x1=i; area.x2=i, area.y1=0; area.y2=YMAX-1;
			sh8601_mspi_set_transfer_window(&area);
			sh8601_mspi_nonblocking_write( buf, YMAX*2, true);
		}
}
/******************************************************************************/
/*                                                                            */
/* Blank_H                                                                    */
/*                                                                            */
/******************************************************************************/
void Blank_H(uint8_t rgb)
{
		uint8_t buf[XMAX*2]; // 16bit
		uint8_t c0;
		uint8_t c1;

		switch(rgb)
		{
			case _BLACK: c0=0x00; c1=0x00; break;
			case _RED:   c0=0xF8; c1=0x00; break;
			case _GREEN: c0=0x07; c1=0xE0; break;
			case _BLUE:  c0=0x00; c1=0x1F; break;
			case _WHITE: c0=0xFF; c1=0xFF; break;
		}
		for(uint32_t i=0; i<XMAX; i++)
		{
				buf[i*2+0]=c0;
				buf[i*2+1]=c1;
		}
		lv_area_t area;
		for(uint32_t i=0; i<YMAX; i++)
		{
			area.x1=0; area.x2=XMAX-1; area.y1=i; area.y2=i;
			sh8601_mspi_set_transfer_window(&area);
			sh8601_mspi_nonblocking_write( buf, XMAX*2, true);
		}
}
/******************************************************************************/
/*                                                                            */
/* display_line_h                                                             */
/*                                                                            */
/******************************************************************************/
void display_line_h(uint8_t rgb, uint32_t y)
{
		uint8_t buf[XMAX*2]; // 16bit
		uint8_t c0;
		uint8_t c1;

		switch(rgb)
		{
			case _BLACK: c0=0x00; c1=0x00; break;
			case _RED:   c0=0xF8; c1=0x00; break;
			case _GREEN: c0=0x07; c1=0xE0; break;
			case _BLUE:  c0=0x00; c1=0x1F; break;
			case _WHITE: c0=0xFF; c1=0xFF; break;
		}
		for(uint32_t i=0; i<XMAX; i++)
		{
				buf[i*2+0]=c0;
				buf[i*2+1]=c1;
		}
		lv_area_t area;
		area.x1=0; area.x2=XMAX-1; area.y1=y; area.y2=y;
		sh8601_mspi_set_transfer_window(&area);
		sh8601_mspi_nonblocking_write( buf, XMAX*2, true);
}
/******************************************************************************/
/*                                                                            */
/* display_line_v                                                             */
/*                                                                            */
/******************************************************************************/
void display_line_v(uint8_t rgb, uint32_t x)
{
		uint8_t buf[YMAX*2]; // 16bit
		uint8_t c0;
		uint8_t c1;

		switch(rgb)
		{
			case _BLACK: c0=0x00; c1=0x00; break;
			case _RED:   c0=0xF8; c1=0x00; break;
			case _GREEN: c0=0x07; c1=0xE0; break;
			case _BLUE:  c0=0x00; c1=0x1F; break;
			case _WHITE: c0=0xFF; c1=0xFF; break;
		}
		for(uint32_t i=0; i<YMAX; i++)
		{
				buf[i*2+0]=c0;
				buf[i*2+1]=c1;
		}
		lv_area_t area;
		area.x1=x; area.x2=x; area.y1=0; area.y2=YMAX-1;
		sh8601_mspi_set_transfer_window(&area);
		sh8601_mspi_nonblocking_write( buf, YMAX*2, true);
}
/******************************************************************************/
/*                                                                            */
/* display_window                                                             */
/*                                                                            */
/******************************************************************************/
void display_window(uint8_t rgb, uint32_t x0, uint32_t x1, uint32_t y0, uint32_t y1)
{
		uint8_t c0;
		uint8_t c1;

		switch(rgb)
		{
			case _BLACK: c0=0x00; c1=0x00; break;
			case _RED:   c0=0xF8; c1=0x00; break;
			case _GREEN: c0=0x07; c1=0xE0; break;
			case _BLUE:  c0=0x00; c1=0x1F; break;
			case _WHITE: c0=0xFF; c1=0xFF; break;
		}

		uint8_t buf[XMAX*2];
		uint32_t xcnt=(x1-x0+1);
		for(int i=0; i<xcnt; i++)
		{
			buf[2*i+0]=c0;
			buf[2*i+1]=c1;
		}
		lv_area_t area;
		for(int i=0; i<(y1-y0+1); i++)
		{
			area.x1=x0; area.x2=x1; area.y1=y0+i; area.y2=y0+i;
			sh8601_mspi_set_transfer_window(&area);
			sh8601_mspi_nonblocking_write( buf, xcnt*2, true);
		}
}
/******************************************************************************/
/*                                                                            */
/* toggle_display                                                             */
/*                                                                            */
/******************************************************************************/
void toggle_display(void)
{
		static bool toggle=1;

		if(toggle)
		{
			sh8601_mspi_command_write( 0x29, NULL, 0); // Display On
		}
		else
		{
			sh8601_mspi_command_write( 0x28, NULL, 0); // Display Off
		}
		toggle^=1;
}
/******************************************************************************/
/*                                                                            */
/* toggle_display_color                                                       */
/*                                                                            */
/******************************************************************************/
void toggle_display_color(void)
{
		static uint8_t id=0;
		switch(id)
		{
			case 0: Blank_H(_RED); break;
			case 1: Blank_H(_GREEN); break;
			case 2: Blank_H(_BLUE); break;
		}
		id++;
		id%=3;
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/


