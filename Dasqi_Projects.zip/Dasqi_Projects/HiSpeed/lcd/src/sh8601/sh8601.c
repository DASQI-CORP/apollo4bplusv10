






/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\lcd\lcd.h"
#include "sh8601.h"
#include "lv_area.h"
/******************************************************************************/
/*                                                                            */
/* Global Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
/******************************************************************************/
uint8_t dma_buf[DMA_BUF_SIZE];//words size vcpi
/******************************************************************************/
/*                                                                            */
/* QuadCE0DisplayMSPICfg                                                      */
/*                                                                            */
/******************************************************************************/
am_hal_mspi_dev_config_t  QuadCE0DisplayMSPICfg =
{
		.eSpiMode             = AM_HAL_MSPI_SPI_MODE_0,
		.eClockFreq           = AM_HAL_MSPI_CLK_48MHZ,
		.ui8TurnAround        = 0,
		.eAddrCfg             = AM_HAL_MSPI_ADDR_3_BYTE,
		.eInstrCfg            = AM_HAL_MSPI_INSTR_1_BYTE,
		.eDeviceConfig        = AM_HAL_MSPI_FLASH_QUAD_CE0_1_4_4,
		.bSendInstr           = true,
		.bSendAddr            = true,
		.bTurnaround          = false,
		.ui8WriteLatency      = 0,
		.bEnWriteLatency      = false,
		.bEmulateDDR          = false,
		.ui16DMATimeLimit     = 0,
		.eDMABoundary         = AM_HAL_MSPI_BOUNDARY_NONE,
		.ui16ReadInstr        = AM_DEVICES_MSPI_RM69330_FAST_READ,
		.ui16WriteInstr       = AM_DEVICES_MSPI_RM69330_PIXEL_WRITE_ADDR4,
};
/******************************************************************************/
/*                                                                            */
/* gAmDisplay                                                                 */
/*                                                                            */
/******************************************************************************/
am_devices_mspi_rm69330_t gAmDisplay;
/******************************************************************************/
/*                                                                            */
/* am_mspi2_isr                                                               */
/*                                                                            */
/******************************************************************************/
void am_mspi2_isr(void)
{
		uint32_t ui32Status;
	
  	am_hal_mspi_interrupt_status_get(gAmDisplay.pMspiHandle, &ui32Status, false);
		am_hal_mspi_interrupt_clear(gAmDisplay.pMspiHandle, ui32Status);
		am_hal_mspi_interrupt_service(gAmDisplay.pMspiHandle, ui32Status);

		#if 0
		am_util_stdio_printf("am_mspi2_isr()\n");
		#endif
}
/******************************************************************************/
/*                                                                            */
/* call back                                                                  */
/*                                                                            */
/******************************************************************************/
void pfnMSPI_RM69330_Callback(void *pCallbackCtxt, uint32_t status)
{
		//
		// Set the DMA complete flag.
		//
		#if 0
		am_util_stdio_printf("pfnMSPI_RM69330_Callback()...\n");
		#endif
		*(volatile uint32_t *)pCallbackCtxt = status;
}
/******************************************************************************/
/*                                                                            */
/* sh8601_mspi_reset                                                          */
/*                                                                            */
/******************************************************************************/
uint32_t sh8601_mspi_reset(void)
{
		am_hal_gpio_output_clear(LCD_RST_PIN);
		am_util_delay_ms(20);
		am_hal_gpio_output_set(LCD_RST_PIN);
		am_util_delay_ms(150);
		return AM_HAL_STATUS_SUCCESS;
}
/******************************************************************************/
/*                                                                            */
/* sh8601_command write                                                       */
/*                                                                            */
/******************************************************************************/
uint32_t sh8601_mspi_command_write( uint32_t ui32Instr, uint8_t *pData, uint32_t ui32NumBytes)
{
		am_hal_mspi_pio_transfer_t Transaction;

		uint32_t ui32DeviceConfig=(gAmDisplay.mspiDevCfg.eDeviceConfig&1) ? AM_HAL_MSPI_FLASH_SERIAL_CE1 : AM_HAL_MSPI_FLASH_SERIAL_CE0;
		bool bNeedSwitch=false;
		uint32_t ui32Status=AM_DEVICES_MSPI_RM69330_STATUS_SUCCESS;

		if(gAmDisplay.mspiDevCfg.eDeviceConfig>AM_HAL_MSPI_FLASH_SERIAL_CE1)
		{
			bNeedSwitch=true;
		}
		if((!gAmDisplay.bOccupied)||(ui32NumBytes>4))
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		//
		// Switch to Cmd configuration.
		//
		if(bNeedSwitch)
		{
			am_hal_mspi_control(gAmDisplay.pMspiHandle, AM_HAL_MSPI_REQ_DEVICE_CONFIG, &ui32DeviceConfig);
			#if 1 // Clear Command Quene, add by 20221109
			am_hal_mspi_enable(gAmDisplay.pMspiHandle);
			#endif
		}
		//
		// Create the individual write transaction.
		//
		Transaction.ui32NumBytes       = ui32NumBytes;
		Transaction.bScrambling        = false;
		Transaction.eDirection         = AM_HAL_MSPI_TX;
		Transaction.bSendAddr          = true;
		Transaction.ui32DeviceAddr     = ui32Instr << 8;
		Transaction.bSendInstr         = true;
		Transaction.ui16DeviceInstr    = AM_DEVICES_MSPI_RM69330_CMD_WRITE; // 0x02
		Transaction.bTurnaround        = false;
		Transaction.bDCX               = false;
		Transaction.bEnWRLatency       = false;
		Transaction.bContinue          = false;
		Transaction.pui32Buffer        = (uint32_t*)pData;
		//
		// Execute the transaction over MSPI.
		//
		ui32Status=am_hal_mspi_blocking_transfer(gAmDisplay.pMspiHandle, &Transaction, AM_DEVICES_MSPI_RM69330_TIMEOUT);
		if(AM_HAL_STATUS_SUCCESS!=ui32Status)
		{
			am_util_stdio_printf("am_hal_mspi_blocking_transfer(0x%02X) Failed...Error Code=%d.\n", ui32Instr, ui32Status);
			#if 1 // Clear Command Quene, add by 20221109
			am_hal_mspi_enable(gAmDisplay.pMspiHandle);
			#endif
		}
		//
		// Switch to Device configuration.
		//
		if(bNeedSwitch)
		{
			//
			// Re-Configure the MSPI for the requested operation mode.
			//
			ui32Status=am_hal_mspi_device_configure(gAmDisplay.pMspiHandle, &gAmDisplay.mspiDevCfg);
			if(AM_HAL_STATUS_SUCCESS!=ui32Status)
			{
				am_util_stdio_printf("am_hal_mspi_device_configure() Failed, Error Code=%d\n", ui32Status);
			}
			//
			// Re-Enable MSPI
			//
			ui32Status=am_hal_mspi_enable(gAmDisplay.pMspiHandle);
			if(AM_HAL_STATUS_SUCCESS!=ui32Status)
			{
				am_util_stdio_printf("am_hal_mspi_enable() Failed.\n");
			}
			//
			// Configure the MSPI pins.
			//
			am_bsp_mspi_pins_enable(gAmDisplay.ui32Module, gAmDisplay.mspiDevCfg.eDeviceConfig);
		}

		return ui32Status;
}
/******************************************************************************/
/*                                                                            */
/* sh8601_mspi_nonblocking_write                                              */
/*                                                                            */
/******************************************************************************/
uint32_t sh8601_mspi_nonblocking_write( const uint8_t *pui8TxBuffer, uint32_t ui32NumBytes, bool bWaitForCompletion)
{
		
		uint32_t ui32BytesLeft=ui32NumBytes;
		uint32_t ui32Status;

		am_hal_mspi_dma_transfer_t Transaction;
		while(ui32BytesLeft)
		{
			if(ui32BytesLeft==ui32NumBytes)
			{
				Transaction.ui32DeviceAddress=AM_DEVICES_MSPI_RM69330_MEM_WRITE<<8; // 0x2C
			}
			else
			{
				Transaction.ui32DeviceAddress=AM_DEVICES_MSPI_RM69330_MEM_WRITE_CONTINUE<<8; // 0x3C
			}
			//
			// Set the DMA priority
			//
			Transaction.ui8Priority=1;
			//
			// Set the transfer direction to TX (Write)
			//
			Transaction.eDirection = AM_HAL_MSPI_TX;
			//
			// Count
			//
			Transaction.ui32TransferCount = (ui32BytesLeft > BYTE_NUM_PER_WRITE) ? BYTE_NUM_PER_WRITE : ui32BytesLeft;
			//
			// Set the source SRAM buffer address.
			//
			Transaction.ui32SRAMAddress = (uint32_t)pui8TxBuffer;
			//
			// Clear the CQ stimulus.
			//
			Transaction.ui32PauseCondition = 0;
			//
			// Clear the post-processing
			//
			Transaction.ui32StatusSetClr = 0;
			//
			// Start the transaction.
			//
			volatile uint32_t ui32DMAStatus = 0xFFFFFFFF;
			ui32Status=am_hal_mspi_nonblocking_transfer(
																										gAmDisplay.pMspiHandle, 
																										&Transaction, 
																										AM_HAL_MSPI_TRANS_DMA, // AM_HAL_MSPI_TRANS_PIO
																										pfnMSPI_RM69330_Callback, 
																										(void *)&ui32DMAStatus // &ui32DMAStatus=pCallbackCtxt
																									); 
			//
			// Check the transaction status.
			//
			if(AM_HAL_STATUS_SUCCESS!=ui32Status)
			{
				#if 1
				am_util_stdio_printf("am_hal_mspi_nonblocking_transfer()...Error, Error Code=%d\n", ui32Status);
				#endif

				return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
			}
			//
			// Wait for DMA Complete or Timeout
			//
			if (bWaitForCompletion)
			{
				for(uint32_t i=0; i<AM_DEVICES_MSPI_RM69330_TIMEOUT; i++) // 100000us=100ms
				{
					if(AM_HAL_STATUS_SUCCESS==ui32DMAStatus)
					{
						break;
					}
					am_util_delay_us(1);
				}
				if(AM_HAL_STATUS_SUCCESS!=ui32DMAStatus)
				{
					return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
				}
			}
			ui32BytesLeft-=Transaction.ui32TransferCount;
			pui8TxBuffer+=Transaction.ui32TransferCount;

		}

		return AM_DEVICES_MSPI_RM69330_STATUS_SUCCESS;
}
/******************************************************************************/
/*                                                                            */
/* sh8601_mspi_lcm_init                                                       */
/*                                                                            */
/******************************************************************************/
uint32_t sh8601_mspi_lcm_init(void)
{
		uint8_t cmd_buf[10];
		//
		// Sleep Out 0x11
		//
		if(sh8601_mspi_command_write( 0x11, NULL, 0))
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		//
		// Delay 120ms
		//
		am_util_delay_ms(120); // delay 120ms
		//
		// Column Address Set 0x2A
		//
		cmd_buf[0]=0x00;
		cmd_buf[1]=0x00; 
		cmd_buf[2]=(XMAX-1)>>8;
		cmd_buf[3]=(XMAX-1)%256;
		if(sh8601_mspi_command_write( 0x2A, cmd_buf, 4))
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		//
		// Page Address Set 0x2B
		//
		cmd_buf[0]=0x00;
		cmd_buf[1]=0x00; 
		cmd_buf[2]=(YMAX-1)>>8;
		cmd_buf[3]=(YMAX-1)%256;
		if(sh8601_mspi_command_write( 0x2B, cmd_buf, 4))
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		//
		// Write Tearing Effect Scan Line 0x44
		//
		cmd_buf[0]=(XMAX-1)>>8; // cmd_buf[0]=(XMAX-1)/256;
		cmd_buf[1]=(XMAX-1)%256;
		if(sh8601_mspi_command_write( 0x44, cmd_buf, 2))
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		//
		// Tearing Effect On 0x35
		//
		cmd_buf[0]=0x00;
		if(sh8601_mspi_command_write( 0x35, cmd_buf, 1))
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		//
		// Write Pixel Format 0x3A
		//
		cmd_buf[0]=0x55; // 0x55=16Bit, 0x77=24Bit
		if(sh8601_mspi_command_write( 0x3A, cmd_buf, 1))
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		//
		// Write CTRL Display 1 0x53
		//
		cmd_buf[0]=0x20; // 0x20=Brightness Control On
		if(sh8601_mspi_command_write( 0x53, cmd_buf, 1))
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		//
		// Memory Data Access Control 0x36
		//
		cmd_buf[0]=0x00; // 0x00=RGB16, 0x08=BGR16, 0x40 flip left to right
		if(sh8601_mspi_command_write( 0x36, cmd_buf, 1)) // 0x36=MADCL=Memory Data Access Control
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		//
		// Write Display Brightness Value 0x51
		//
		cmd_buf[0]=0xFF; // [7:0]
		cmd_buf[1]=0x03; // [9:8]
		if(sh8601_mspi_command_write( 0x51, cmd_buf, 2)) // 0x51=WRDISBV
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		//
		// Delay 25ms
		//
		am_util_delay_ms(25);
		//
		// Display On 0x29
		//
		if(sh8601_mspi_command_write( 0x29, NULL, 0)) // Display On
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}

		return AM_DEVICES_MSPI_RM69330_STATUS_SUCCESS;
}
/******************************************************************************/
/*                                                                            */
/* SH8601 init                                                                */
/*                                                                            */
/******************************************************************************/

uint32_t sh8601_init(uint32_t ui32Module)
{
		uint32_t ui32Status;
		

		if(ui32Module>AM_REG_MSPI_NUM_MODULES)
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		
		
		gAmDisplay.mspiDevCfg=QuadCE0DisplayMSPICfg;

		//
		// Mspi Initialize
		//
		if(AM_HAL_STATUS_SUCCESS!=am_hal_mspi_initialize(ui32Module, &gAmDisplay.pMspiHandle))
		{
			am_util_stdio_printf("am_hal_mspi_initialize() Failed.\n");
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		#if SH8601_PRINT
		am_util_stdio_printf("am_hal_mspi_initialize() OK.\n");
		#endif

		//
		// Mspi Power Control
		//
		if(AM_HAL_STATUS_SUCCESS!=am_hal_mspi_power_control(gAmDisplay.pMspiHandle, AM_HAL_SYSCTRL_WAKE, false))
		{
			am_util_stdio_printf("am_hal_mspi_power_control() Failed.\n");
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		#if SH8601_PRINT
		am_util_stdio_printf("am_hal_mspi_power_control() OK.\n");
		#endif

		//
		// Mspi Configuration
		//
		gAmDisplay.mspiConf.ui32TCBSize= DMA_BUF_SIZE/4; // dword size
		gAmDisplay.mspiConf.pTCB = (uint32_t *)dma_buf;
		gAmDisplay.mspiConf.bClkonD4=0;
		if(AM_HAL_STATUS_SUCCESS!=am_hal_mspi_configure(gAmDisplay.pMspiHandle, &gAmDisplay.mspiConf))
		{
			am_util_stdio_printf("am_hal_mspi_configure() Failed.\n");
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		#if SH8601_PRINT
		am_util_stdio_printf("am_hal_mspi_configure() OK.\n");
		#endif

		//
		// Mspi Device Configuration
		//
		if(AM_HAL_STATUS_SUCCESS!=am_hal_mspi_device_configure(gAmDisplay.pMspiHandle, &gAmDisplay.mspiDevCfg))
		{
			am_util_stdio_printf("am_hal_mspi_device_configure() Failed.\n");
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		#if SH8601_PRINT
		am_util_stdio_printf("am_hal_mspi_device_configure() OK.\n");
		#endif

		//
		// Enable Mspi
		// 
		if(AM_HAL_STATUS_SUCCESS!=am_hal_mspi_enable(gAmDisplay.pMspiHandle))
		{
			am_util_stdio_printf("am_hal_mspi_enable() Failed.\n");
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		#if SH8601_PRINT
		am_util_stdio_printf("am_hal_mspi_enable() OK.\n");
		#endif

		//
		// Mspi_pins_enable
		//
		am_bsp_mspi_pins_enable(ui32Module, gAmDisplay.mspiDevCfg.eDeviceConfig);
		//
		// mspi_lcm_init
		//
		gAmDisplay.bOccupied=true;
		sh8601_mspi_lcm_init();
		//
		// Mspi Interrupt Clear
		//
		ui32Status=am_hal_mspi_interrupt_clear(gAmDisplay.pMspiHandle, AM_HAL_MSPI_INT_CQUPD|AM_HAL_MSPI_INT_ERR);
		if(AM_HAL_STATUS_SUCCESS!=ui32Status)
		{
			am_util_stdio_printf("am_hal_mspi_interrupt_clear() Failed.\n");
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		#if SH8601_PRINT
		am_util_stdio_printf("am_hal_mspi_interrupt_clear() OK.\n");
		#endif
		//
		// Mspi Enable Interrupt
		//
		ui32Status = am_hal_mspi_interrupt_enable(gAmDisplay.pMspiHandle, AM_HAL_MSPI_INT_CQUPD|AM_HAL_MSPI_INT_ERR);
		if (AM_HAL_STATUS_SUCCESS!=ui32Status)
		{
			am_util_stdio_printf("am_hal_mspi_interrupt_enable() Failed.\n");
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}
		#if SH8601_PRINT
		am_util_stdio_printf("am_hal_mspi_interrupt_enable() OK.\n");
		#endif
		//
		// mspi init finished
		//
		#if SH8601_PRINT
		am_util_stdio_printf("mspi_init() OK.\n");
		#endif

		return AM_DEVICES_MSPI_RM69330_STATUS_SUCCESS;
}
/******************************************************************************/
/*                                                                            */
/* sh8601_mspi_set_transfer_window                                            */
/*                                                                            */
/******************************************************************************/
uint32_t sh8601_mspi_set_transfer_window(lv_area_t *area)
{
		uint8_t cmd_buf[4];

		/*
		uint32_t col_start; 
		uint32_t col_end;
		uint32_t row_start;
		uint32_t row_end;

		col_start = area->x1;
		col_end = area->x2;
		row_start = area->y1;
		row_end = area->y2;

		cmd_buf[0]=(col_start>>8);
		cmd_buf[1]=(col_start&0xff);
		cmd_buf[2]=(col_end>>8);
		cmd_buf[3]=(col_end&0xff);
		*/


		cmd_buf[0]=(area->x1>>8);
		cmd_buf[1]=(area->x1&0xff);
		cmd_buf[2]=(area->x2>>8);
		cmd_buf[3]=(area->x2&0xff);




		if(sh8601_mspi_command_write( 0x2A, cmd_buf, 4))
		{
			return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}

		/*
		cmd_buf[0]=(row_start>>8);
		cmd_buf[1]=(row_start&0xff);
		cmd_buf[2]=(row_end>>8);
		cmd_buf[3]=(row_end&0xff);
		*/
		cmd_buf[0]=(area->y1>>8);
		cmd_buf[1]=(area->y1&0xff);
		cmd_buf[2]=(area->y2>>8);
		cmd_buf[3]=(area->y2&0xff);


		if(sh8601_mspi_command_write( 0x2B, cmd_buf, 4))
		{
				return AM_DEVICES_MSPI_RM69330_STATUS_ERROR;
		}

		return AM_DEVICES_MSPI_RM69330_STATUS_SUCCESS;
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/









































