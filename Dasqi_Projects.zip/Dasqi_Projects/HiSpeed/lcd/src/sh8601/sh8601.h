




#ifndef _SH8601_H
#define _SH8601_H
/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\main.h"
#include "..\lcd\lcd.h"
#include "lv_area.h"
/******************************************************************************/
/*                                                                            */
/* Global Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
#define SH8601_PRINT 1
/******************************************************************************/
/*                                                                            */
/* Display Dimensions                                                         */
/*                                                                            */
/******************************************************************************/
#define AM_DEVICES_RM69330_NUM_ROWS    YMAX
#define AM_DEVICES_RM69330_NUM_COLUMNS XMAX
/******************************************************************************/
#define AM_DEVICES_MSPI_RM69330_TIMEOUT 100000 // 100000us=100ms
/******************************************************************************/
#define BYTE_NUM_PER_WRITE XMAX*YMAX*2
#define DMA_BUF_SIZE XMAX*20*2 // bytes
/******************************************************************************/
/*                                                                            */
/* Parameters                                                                 */
/*                                                                            */
/******************************************************************************/
/******************************************************************************/
/*                                                                            */
/* Commands                                                                   */
/*                                                                            */
/******************************************************************************/
#define AM_DEVICES_MSPI_RM69330_FAST_READ           0x0B
#define AM_DEVICES_MSPI_RM69330_PIXEL_WRITE_ADDR4   0x12
#define AM_DEVICES_MSPI_RM69330_MEM_WRITE           0x2C
#define AM_DEVICES_MSPI_RM69330_MEM_WRITE_CONTINUE  0x3C
#define AM_DEVICES_MSPI_RM69330_CMD_WRITE           0x02
/******************************************************************************/
/*                                                                            */
/* Registers                                                                  */
/*                                                                            */
/******************************************************************************/
#define MAX_DEVICE_NUM 1
/******************************************************************************/
/*                                                                            */
/* am_devices_mspi_rm69330_status_t                                           */
/*                                                                            */
/******************************************************************************/
typedef enum
{
		AM_DEVICES_MSPI_RM69330_STATUS_SUCCESS,
		AM_DEVICES_MSPI_RM69330_STATUS_ERROR
} am_devices_mspi_rm69330_status_t;
/******************************************************************************/
/*                                                                            */
/* am_devices_mspi_rm69330_t                                                  */
/*                                                                            */
/******************************************************************************/
typedef struct
{
		uint32_t ui32Module;
		void *pMspiHandle;//am_hal_mspi_state_t
		am_hal_mspi_dev_config_t mspiDevCfg;
		am_hal_mspi_config_t mspiConf;
		uint8_t bOccupied;
} am_devices_mspi_rm69330_t;
/******************************************************************************/
/*                                                                            */
/* Global Variables                                                           */
/*                                                                            */
/******************************************************************************/
#define LcdMSPModule 2
/******************************************************************************/
/*                                                                            */
/* Functions                                                                  */
/*                                                                            */
/******************************************************************************/
extern uint32_t sh8601_mspi_reset(void);
extern uint32_t sh8601_mspi_command_write(uint32_t ui32Instr, uint8_t *pData, uint32_t ui32NumBytes);
extern uint32_t sh8601_mspi_nonblocking_write(const uint8_t *pui8TxBuffer, uint32_t ui32NumBytes, bool bWaitForCompletion);
extern uint32_t sh8601_mspi_lcm_init(void);
extern uint32_t sh8601_init(uint32_t ui32Module);
extern uint32_t sh8601_mspi_set_transfer_window(lv_area_t *area);
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
#endif


/*
  typedef enum
  {
    AM_HAL_STATUS_SUCCESS, // 0
    AM_HAL_STATUS_FAIL, // 1
    AM_HAL_STATUS_INVALID_HANDLE, // 2
    AM_HAL_STATUS_IN_USE, // 3
    AM_HAL_STATUS_TIMEOUT, // 4
    AM_HAL_STATUS_OUT_OF_RANGE, // 5
    AM_HAL_STATUS_INVALID_ARG,
    AM_HAL_STATUS_INVALID_OPERATION, // 7
    AM_HAL_STATUS_MEM_ERR,
    AM_HAL_STATUS_HW_ERR,
    AM_HAL_STATUS_MODULE_SPECIFIC_START = 0x08000000,
  } am_hal_status_e;
*/

