


/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\main.h"
#include "..\FatFs\ff.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
#define I2S_PRINT 1
/******************************************************************************/
#define I2S_MODULE_0 0
#define I2S_MODULE_1 1
/******************************************************************************/
#define SIZE_SAMPLES 128 // 4*128=512
/******************************************************************************/
// I2S0 Pin Define
#define I2S0_DATA_IN_GPIO_FUNC AM_HAL_PIN_14_I2S0_SDIN
#define I2S0_DATA_IN_GPIO_PIN 14
#define I2S0_DATA_OUT_GPIO_FUNC AM_HAL_PIN_12_I2S0_SDOUT
#define I2S0_DATA_OUT_GPIO_PIN 12
#define I2S0_CLK_GPIO_FUNC AM_HAL_PIN_11_I2S0_CLK
#define I2S0_CLK_GPIO_PIN 11
#define I2S0_WS_GPIO_FUNC AM_HAL_PIN_13_I2S0_WS
#define I2S0_WS_GPIO_PIN 13
/******************************************************************************/
// I2S1 Pin Define
#define I2S1_DATA_IN_GPIO_FUNC AM_HAL_PIN_19_I2S1_SDIN
#define I2S1_DATA_IN_GPIO_PIN 19
#define I2S1_DATA_OUT_GPIO_FUNC AM_HAL_PIN_17_I2S1_SDOUT
#define I2S1_DATA_OUT_GPIO_PIN 17
#define I2S1_CLK_GPIO_FUNC AM_HAL_PIN_16_I2S1_CLK
#define I2S1_CLK_GPIO_PIN 16
#define I2S1_WS_GPIO_FUNC AM_HAL_PIN_18_I2S1_WS
#define I2S1_WS_GPIO_PIN 18
/******************************************************************************/
// extern uint32_t Next_Sector_And_Rewind(stream_t *pF);

extern uint32_t ui32I2S0TxDataPtr;
extern uint32_t BufIndex;
extern const IRQn_Type i2s_interrupts[];
extern void *pI2S0Handle;
extern void *pI2S1Handle;
extern FIL fWave;
/******************************************************************************/
/*                                                                            */
/* Functions                                                                  */
/*                                                                            */
/******************************************************************************/
extern void fill_buffer0(void);
extern void fill_buffer1(void);
extern void i2s_init_data(void);
extern void am_dspi2s0_isr(void);
extern void i2s_hw_init(void);
extern void i2s_init(void);
/******************************************************************************/



