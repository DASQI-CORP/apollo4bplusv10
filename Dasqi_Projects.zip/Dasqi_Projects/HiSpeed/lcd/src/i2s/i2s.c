



/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "i2s.h"
#include "..\wave\wave.h"
#include "..\FatFs\ff.h"
#include "..\sdcard_disk\sdcard_disk.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
uint32_t ui32I2S0TxDataPtr;
uint32_t BufIndex;
void *pI2S0Handle;
void *pI2S1Handle;
/*****************************************************************************/
/*                                                                           */
/* I2S interrupts.                                                           */
/*                                                                           */
/*****************************************************************************/
const IRQn_Type i2s_interrupts[] =
{
		I2S0_IRQn, // 44
		I2S1_IRQn, // 45
};
/*****************************************************************************/
/*                                                                           */
/* AXI Scratch buffer                                                        */
/* Need to allocate 20 Words even though we only need 16,                    */
/* to ensure we have 16 Byte alignment                                       */
/* AM_SHARED_RW=__attribute__((section("SHARED_RW"))) __attribute__((used))  */
/*                                                                           */
/*****************************************************************************/
AM_SHARED_RW uint32_t axiScratchBuf[20];
/*****************************************************************************/
/*                                                                           */
/* Used as pingpong buffer internally.                                       */
/* Buffers are to be padded at 16B alignment                                 */
/*                                                                           */
/*****************************************************************************/
AM_SHARED_RW uint32_t g_ui32I2S0TxDataBuffer[2*SIZE_SAMPLES+3];
/******************************************************************************/
/*                                                                            */
/* g_sI2SIOConfig                                                             */
/*                                                                            */
/******************************************************************************/
static am_hal_i2s_io_signal_t g_sI2SIOConfig =
{
		.eFyncCpol = AM_HAL_I2S_IO_FSYNC_CPOL_HIGH,
		.eTxCpol = AM_HAL_I2S_IO_TX_CPOL_FALLING,
		.eRxCpol = AM_HAL_I2S_IO_RX_CPOL_RISING // Data Should be Read on Rising Edge
};
/******************************************************************************/
/*                                                                            */
/* g_sI2SDataConfig                                                           */
/*                                                                            */
/******************************************************************************/
static am_hal_i2s_data_format_t g_sI2SDataConfig =
{
		.ePhase = AM_HAL_I2S_DATA_PHASE_SINGLE,
		.eDataDelay = 0x1,
		.ui32ChannelNumbersPhase1 = 2,
		.ui32ChannelNumbersPhase2 = 2,
		.eDataJust = AM_HAL_I2S_DATA_JUSTIFIED_LEFT, // 5102_FMT=High=Left Justified, AM_HAL_I2S_DATA_JUSTIFIED_RIGHT
		.eChannelLenPhase1 = AM_HAL_I2S_FRAME_WDLEN_16BITS, // AM_HAL_I2S_FRAME_WDLEN_32BITS,
		.eChannelLenPhase2 = AM_HAL_I2S_FRAME_WDLEN_16BITS, // AM_HAL_I2S_FRAME_WDLEN_32BITS,
		.eSampleLenPhase1 = AM_HAL_I2S_SAMPLE_LENGTH_16BITS, //AM_HAL_I2S_SAMPLE_LENGTH_24BITS,
		.eSampleLenPhase2 = AM_HAL_I2S_SAMPLE_LENGTH_16BITS // AM_HAL_I2S_SAMPLE_LENGTH_24BITS
};
/******************************************************************************/
/*                                                                            */
/* g_sI2S0Config                                                              */
/*                                                                            */
/******************************************************************************/
static am_hal_i2s_config_t g_sI2S0Config =
{
		.eClock = eAM_HAL_I2S_CLKSEL_HFRC_1_5MHz, // 44100*16*2=1.411200MHz
		.eDiv3 = 0,
		.eASRC = 0,
		.eMode = AM_HAL_I2S_IO_MODE_MASTER,
		.eXfer = AM_HAL_I2S_XFER_TX,
		.eData = &g_sI2SDataConfig,
		.eIO = &g_sI2SIOConfig
};
/******************************************************************************/
/*                                                                            */
/* sTransfer0                                                                 */
/*                                                                            */
/******************************************************************************/
static am_hal_i2s_transfer_t sTransfer0 =
{
		.ui32TxTotalCount = SIZE_SAMPLES,
		.ui32TxTargetAddr = 0x0,
		.ui32TxTargetAddrReverse = 0x0,
		.ui32RxTotalCount = SIZE_SAMPLES,
		.ui32RxTargetAddr = 0x0,
		.ui32RxTargetAddrReverse  = 0x0,
};
/******************************************************************************/
/*                                                                            */
/* fill_buffer 0                                                              */
/*                                                                            */
/******************************************************************************/
void fill_buffer0(void)
{
		if(f_eof(&fWave))
		{
			f_rewind(&fWave);
		}

		uint32_t read_cnt;
		if(f_read(&fWave, (uint8_t*)(ui32I2S0TxDataPtr+0*sizeof(uint32_t)*SIZE_SAMPLES), sizeof(uint32_t)*SIZE_SAMPLES, (UINT*)&read_cnt)!=FR_OK)
		{
			am_hal_reset_control(AM_HAL_RESET_CONTROL_SWPOI, 0);
		}
}
/******************************************************************************/
/*                                                                            */
/* fill_buffer 1                                                              */
/*                                                                            */
/******************************************************************************/
void fill_buffer1(void)
{
		if(f_eof(&fWave))
		{
			f_rewind(&fWave);
		}

		uint32_t read_cnt;
		if(f_read(&fWave, (uint8_t*)(ui32I2S0TxDataPtr+1*sizeof(uint32_t)*SIZE_SAMPLES), sizeof(uint32_t)*SIZE_SAMPLES, (UINT*)&read_cnt)!=FR_OK)
		{
			am_hal_reset_control(AM_HAL_RESET_CONTROL_SWPOI, 0);
		}
}
/******************************************************************************/
/*                                                                            */
/* i2s_init_data                                                              */
/*                                                                            */
/******************************************************************************/
void i2s_init_data(void)
{
		//
		// I2S DMA data config, DMA buffers padded at 16B alignment.
		//
		ui32I2S0TxDataPtr=(uint32_t)((uint32_t)(g_ui32I2S0TxDataBuffer+3)&~0xF);

		BufIndex=0;
		fill_buffer0();
		fill_buffer1();
}
/******************************************************************************/
/*                                                                            */
/* am_dspi2s0_isr                                                             */
/*                                                                            */
/******************************************************************************/
void am_dspi2s0_isr(void)
{
		uint32_t ui32Status;
		static bool firsttime=true;

		am_hal_i2s_interrupt_status_get(pI2S0Handle, &ui32Status, true);
		am_hal_i2s_interrupt_clear(pI2S0Handle, ui32Status);
		//
		// I2S interrupt service
		//
		am_hal_i2s_interrupt_service(pI2S0Handle, ui32Status, &g_sI2S0Config);

		if(ui32Status & AM_HAL_I2S_INT_TXDMACPL)
		{
			if(firsttime)
			{
				firsttime=false;
			}
			else
			{
				BufIndex++;
				BufIndex%=2;
				switch(BufIndex)
				{
					case 0: fill_buffer0(); break;
					case 1: fill_buffer1(); break;
				}
			}
		}

		if(ui32Status & AM_HAL_I2S_INT_RXDMACPL){}
}
/******************************************************************************/
/*                                                                            */
/* i2s_hw_init                                                                */
/*                                                                            */
/******************************************************************************/
void i2s_hw_init(void)
{
		am_hal_gpio_pincfg_t sPinCfg =
		{
			.GP.cfg_b.eGPOutCfg = 1,
			.GP.cfg_b.ePullup   = 0
		};
		//
		// I2S0
		//
		sPinCfg.GP.cfg_b.uFuncSel = I2S0_DATA_OUT_GPIO_FUNC;
		am_hal_gpio_pinconfig(I2S0_DATA_OUT_GPIO_PIN, sPinCfg);
		sPinCfg.GP.cfg_b.uFuncSel = I2S0_DATA_IN_GPIO_FUNC;
		am_hal_gpio_pinconfig(I2S0_DATA_IN_GPIO_PIN, sPinCfg);
		sPinCfg.GP.cfg_b.uFuncSel = I2S0_CLK_GPIO_FUNC;
		am_hal_gpio_pinconfig(I2S0_CLK_GPIO_PIN, sPinCfg);
		sPinCfg.GP.cfg_b.uFuncSel = I2S0_WS_GPIO_FUNC;
		am_hal_gpio_pinconfig(I2S0_WS_GPIO_PIN, sPinCfg);
		am_hal_i2s_initialize(I2S_MODULE_0, &pI2S0Handle);
		am_hal_i2s_power_control(pI2S0Handle, AM_HAL_I2S_POWER_ON, false);
		am_hal_i2s_configure(pI2S0Handle, &g_sI2S0Config);
		am_hal_i2s_enable(pI2S0Handle);

		//
		// Enable hfrc2.
		//
		am_hal_clkgen_control(AM_HAL_CLKGEN_CONTROL_HFRC2_START, false);
		am_util_delay_us(500); // wait for FLL to lock

		//
		// Enable EXT CLK32M.
		//
		bool b0=(eAM_HAL_I2S_CLKSEL_XTHS_EXTREF_CLK<=g_sI2S0Config.eClock)&&(g_sI2S0Config.eClock<=eAM_HAL_I2S_CLKSEL_XTHS_500KHz);
		if(b0)
		{
			am_hal_mcuctrl_control(AM_HAL_MCUCTRL_CONTROL_EXTCLK32M_NORMAL, 0);
			am_util_delay_ms(200);
		}
}
/******************************************************************************/
/*                                                                            */
/* i2s_init                                                                   */
/*                                                                            */
/******************************************************************************/
void i2s_init(void)
{
		//
		// Set up scratch AXI buf (needs 64B - aligned to 16 Bytes)
		// AM_SHARED_RW uint32_t axiScratchBuf[20];, 20*4=80Bytes
		//
		am_hal_daxi_control(AM_HAL_DAXI_CONTROL_AXIMEM, (uint8_t *)((uint32_t)(axiScratchBuf + 3) & ~0xF));

		//
		// I2S0
		//
		sTransfer0.ui32TxTargetAddr=ui32I2S0TxDataPtr;
		sTransfer0.ui32TxTargetAddrReverse=sTransfer0.ui32TxTargetAddr+sizeof(uint32_t)*sTransfer0.ui32TxTotalCount;

		i2s_hw_init();

		am_hal_i2s_dma_configure(pI2S0Handle, &g_sI2S0Config, &sTransfer0);

		NVIC_SetPriority(i2s_interrupts[I2S_MODULE_0], 0xFE); // 20221109
		NVIC_EnableIRQ(i2s_interrupts[I2S_MODULE_0]);
		bI2S_IRQ_Enabled=true;
		am_hal_interrupt_master_enable();

		//
		// Start DMA transaction.
		//
		am_hal_i2s_dma_transfer_start(pI2S0Handle, &g_sI2S0Config);
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/











