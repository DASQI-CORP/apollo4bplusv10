

/******************************************************************************/
#include "stimer.h"
#include "lvgl.h"
/******************************************************************************/
volatile uint32_t msec=0;
/******************************************************************************/
void am_stimer_cmpr2_isr(void)
{
		//
		// Check the timer interrupt status.
		//
		am_hal_stimer_int_clear(AM_HAL_STIMER_INT_COMPAREC);
		am_hal_stimer_compare_delta_set(2, WAKE_INTERVAL_C);

		msec++;

		lv_tick_inc(1);
}
/******************************************************************************/
void stimer_init(void)
{
		//
		// Enable compare C interrupt in STIMER
		//
		am_hal_stimer_int_enable(AM_HAL_STIMER_INT_COMPAREC);
		//
		// Enable the timer Comparer 2 interrupt in the NVIC.
		//
		NVIC_SetPriority(STIMER_CMPR2_IRQn, AM_IRQ_PRIORITY_DEFAULT); // AM_IRQ_PRIORITY_DEFAULT=4
		NVIC_EnableIRQ(STIMER_CMPR2_IRQn);
		//
		// Configure the STIMER and run
		//
		am_hal_stimer_config(AM_HAL_STIMER_CFG_CLEAR | AM_HAL_STIMER_CFG_FREEZE);
		am_hal_stimer_compare_delta_set(2, WAKE_INTERVAL_C);
		am_hal_stimer_config(AM_HAL_STIMER_XTAL_32KHZ | AM_HAL_STIMER_CFG_COMPARE_C_ENABLE);
}
/******************************************************************************/






