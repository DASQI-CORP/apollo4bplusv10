



/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "sdcard_rw_test.h"
/******************************************************************************/
/*                                                                            */
/* Dump_Sector                                                                */
/*                                                                            */
/******************************************************************************/
void Dump_Sector(uint8_t *p)
{
		am_util_stdio_printf("\n");

		for(int i=0; i<32; i++)
		{
			am_util_stdio_printf("%04X: ", i*16);
			for(int j=0; j<16; j++)
			{
				am_util_stdio_printf("%02X ", p[i*16+j]);
			}
			am_util_stdio_printf("\n");
		}

		am_util_stdio_printf("\n");
}
/******************************************************************************/
/*                                                                            */
/* sdio_rw_test                                                               */
/*                                                                            */
/******************************************************************************/
void sdio_rw_test(uint8_t mode, uint8_t patn)
{
		uint8_t sdioBuf512[512];

		switch(mode)
		{
			case 0: for(int i=0; i<512; i++)sdioBuf512[i]=patn;
							break;
			case 1:
							for(uint16_t i=0; i<512; i++)sdioBuf512[i]=(uint8_t)(i&0x00FF);
							break;
			case 2:
							for(uint16_t i=0; i<512; i++)
							{
								if((i%2)==0)sdioBuf512[i]=0x55; else sdioBuf512[i]=0xAA;
							}
							break;
		}

		#if 1
		mmc_disk_write(sdioBuf512, eMMCard.ui32MaxBlks-1, 1); // This write seems is a must, strange??
		Dump_Sector(sdioBuf512);
		#endif

		#if 1
		memset(sdioBuf512, 0x00, sizeof(sdioBuf512));
		mmc_disk_read(sdioBuf512, eMMCard.ui32MaxBlks-1, 1);
		Dump_Sector(sdioBuf512);
		#endif
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/





