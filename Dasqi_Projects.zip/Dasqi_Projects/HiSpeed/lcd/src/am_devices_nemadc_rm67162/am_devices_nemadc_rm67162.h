








#ifndef AM_DEVICES_NEMADC_RM67162_H
#define AM_DEVICES_NEMADC_RM67162_H
/******************************************************************************/
/*                                                                            */
/* Global variables and defines                                               */
/*                                                                            */
/******************************************************************************/
#define SPI4_MODE 1
#define DSPI_MODE 2
#define QSPI_MODE 3
/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "stdint.h"
#include "nema_dc.h"
#include "nema_dc_hal.h"
#include "nema_dc_mipi.h"
#include "nema_dc_regs.h"
#include "nema_dc_intern.h"
/******************************************************************************/
/*                                                                            */
/* C                                                                          */
/*                                                                            */
/******************************************************************************/
#ifdef __cplusplus
extern "C"
{
#endif
/******************************************************************************/
/*                                                                            */
/* Functions                                                                  */
/*                                                                            */
/******************************************************************************/
extern void send_MIPI_cmd(uint8_t spi_mode, uint8_t cmd, uint8_t* data, uint8_t l);
extern uint32_t am_devices_nemadc_rm67162_init(uint32_t mode, uint32_t pixel_format, uint16_t resx, uint16_t resy, uint16_t minx, uint16_t miny);
extern uint32_t am_devices_nemadc_rm67162_set_region(uint32_t mode, uint16_t resx, uint16_t resy, uint16_t minx, uint16_t miny);
extern void nemadc_send_frame_single(void);
// extern void nemadc_send_frame_single_start(void);
// extern void nemadc_send_frame_single_end(void);
/******************************************************************************/
/*                                                                            */
/* C                                                                          */
/*                                                                            */
/******************************************************************************/
#ifdef __cplusplus
}
#endif
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
#endif

