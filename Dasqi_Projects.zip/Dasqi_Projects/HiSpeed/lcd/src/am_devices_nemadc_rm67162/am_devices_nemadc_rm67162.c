






/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include <stdint.h>
#include "am_util_delay.h"
#include "am_bsp.h"
/******************************************************************************/
#include "am_devices_nemadc_rm67162.h"
/******************************************************************************/
#include "..\lcd\lcd.h"
/******************************************************************************/
/*                                                                            */
/* send_MIPI_cmd                                                              */
/*                                                                            */
/******************************************************************************/
void send_MIPI_cmd(uint8_t spi_mode, uint8_t cmd, uint8_t* data, uint8_t l)
{
		//
		// Read Original Config
		//
		uint32_t dbi_cfg = nemadc_reg_read(NEMADC_REG_DBIB_CFG);
		//
		// Hold SPI Bus
		// 
		nemadc_MIPI_CFG_out(dbi_cfg | MIPICFG_SPI_HOLD);
		//
		// CMD1_DATA1=0x02
		//
		nemadc_MIPI_out(MIPI_DBIB_CMD | MIPI_MASK_QSPI | CMD1_DATA1);
		//
		// 3 byte cmd
		//
		nemadc_MIPI_out(MIPI_DBIB_CMD | MIPI_MASK_QSPI | MIPI_CMD24 | (cmd << CMD_OFFSET));
		//
		// Parameters
		//
		for ( int i = 0; i < l; i++ )
		{
			nemadc_MIPI_out(MIPI_DBIB_CMD | MIPI_MASK_QSPI | data[i]);
		}
		nemadc_MIPI_CFG_out(dbi_cfg);
}
/******************************************************************************/
/*                                                                            */
/* Set the rm67162 updated region                                             */
/*                                                                            */
/* mode - interface mode                                                      */
/* resx, resy - resolution of frame                                           */
/* minx, miny - start point of panel region to be updated                     */
/*                                                                            */
/* Return Status                                                              */
/*                                                                            */
/******************************************************************************/
uint32_t am_devices_nemadc_rm67162_set_region(uint32_t mode, uint16_t w, uint16_t h, uint16_t xofs, uint16_t yofs)
{
		// uint8_t spi_mode;
		uint8_t cmd_buf[4];
		uint16_t xmax, ymax;

		xmax = xofs + w - 1;
		ymax = yofs + h - 1;
		//
		// Set MIPI Panel region to be updated
		//
		cmd_buf[0] = (uint8_t)(xofs >> 8U);
		cmd_buf[1] = (uint8_t)(xofs  & 0xFFU);
		cmd_buf[2] = (uint8_t)(xmax >> 8U);
		cmd_buf[3] = (uint8_t)(xmax  & 0xFFU);
		send_MIPI_cmd(mode, 0x2A, cmd_buf, 4);

		am_util_delay_us(20);

		cmd_buf[0] = (uint8_t)(yofs >> 8U);
		cmd_buf[1] = (uint8_t)(yofs  & 0xFFU);
		cmd_buf[2] = (uint8_t)(ymax >> 8U);
		cmd_buf[3] = (uint8_t)(ymax  & 0xFFU);
		send_MIPI_cmd(mode, 0x2B, cmd_buf, 4);

		am_util_delay_us(20);

		return 0;
}
/******************************************************************************/
/*                                                                            */
/* Send single frame                                                          */
/*                                                                            */
/* This function sends QSPI/SPI frame to rm67162                              */
/*                                                                            */
/******************************************************************************/
void nemadc_send_frame_single(void)
{
		//
		// Disable clock gating
		//
		nemadc_reg_write(NEMADC_REG_CLKCTRL_CG, 0xAA000000U);
		//
		// Read Original Config
		//
		uint32_t dbi_cfg;
		dbi_cfg = nemadc_reg_read( NEMADC_REG_DBIB_CFG);
		//
		// Hold SPI Bus
		//
		nemadc_MIPI_CFG_out( dbi_cfg | MIPICFG_SPI_HOLD);
		//
		// MIPI_DBIB_CMD=1<<30, MIPI_MASK_QSPI=1<<27, CMD1_DATA4=(SPICMD|QSPIDATA|SPI_WRITE)=(1<<5)|(1<<4)|2=0x32
		//
		nemadc_MIPI_out( MIPI_DBIB_CMD | MIPI_MASK_QSPI | CMD1_DATA4);
		//
		// MIPI_CMD24=1<<29, MIPI_write_memory_start=0x2C, CMD_OFFSET=8
		//
		nemadc_MIPI_out( MIPI_DBIB_CMD | MIPI_MASK_QSPI | MIPI_CMD24 | (MIPI_write_memory_start << CMD_OFFSET));
		//
		// Enable frame end interrupt
		//
		nemadc_reg_write(NEMADC_REG_INTERRUPT, 1 << 4);
		//
		//
		//
		nemadc_set_mode(NEMADC_ONE_FRAME);
		//
		// Wait for transfer to be completed
		//
		//
		// method 1. depend on RTOS
		//
		#if 1
		nemadc_wait_vsync();
		#endif
		//
		// method 2. Pure Delay at least 10ms
		// (1+3)*8+(454*454*2)*8/4=824496bit, (824496/48MHz)=17177us=18ms=58.217fps, actually=15.7ms
		//
		#if 0 // OK
		am_util_delay_ms(18);
		#endif
		//
		// method 3. OK
		//
		#if 0
		while (nemadc_reg_read(NEMADC_REG_INTERRUPT) != 0U)
		{
				AM_CRITICAL_BEGIN
				if (nemadc_reg_read(NEMADC_REG_INTERRUPT) != 0U )
				{
					am_hal_sysctrl_sleep(1);
				}
				AM_CRITICAL_END
		}
		#endif
		//
		// method 4. Polling VSYNC, NG
		//
		#if 0
		while(1)
		{
			uint32_t ui32usMaxDelay = 1000000; // 1 sec
			uint32_t ui32Status;
			// irq_handler sets NEMADC_REG_INTERRUPT to 0. Poll until this happens
			ui32Status = am_hal_delay_us_status_change(ui32usMaxDelay, (uint32_t)&DC->INTERRUPT, 1UL << 4, 0);
			if (ui32Status != AM_HAL_STATUS_SUCCESS)break;
		}
		#endif
		//
		//
		//
		nemadc_MIPI_CFG_out(dbi_cfg);
		//
		// Enable clock gating
		//
		nemadc_reg_write(NEMADC_REG_CLKCTRL_CG, 0);
}
/******************************************************************************/
/*                                                                            */
/* rm67162_init                                                               */
/*                                                                            */
/* Initialize the rm67162 driver                                              */
/*                                                                            */
/* mode - interface mode                                                      */
/* pixel_format - pixel color format                                          */
/* resx, resy - resolution of frame                                           */
/* minx, miny - start point of panel region to be updated                     */
/*                                                                            */
/* This function should be called before any other am_devices_rm67162         */
/* functions. It is used to set tell the other functions how to communicate   */
/* with the OLED display hardware.                                            */
/*                                                                            */
/* return Status.                                                             */
/*                                                                            */
/******************************************************************************/
uint32_t am_devices_nemadc_rm67162_init(uint32_t mode, uint32_t pixel_format, uint16_t resx, uint16_t resy, 
                                            uint16_t minx, uint16_t miny)
{
		#if 0 // NG
		uint8_t ui8LanesNum = 1;
		uint8_t ui8DbiWidth = AM_HAL_DSI_DBI_WIDTH_8; // AM_HAL_DSI_DBI_WIDTH_16
		uint32_t ui32FreqTrim = AM_HAL_DSI_FREQ_TRIM_X12; // AM_HAL_DSI_FREQ_TRIM_X1~AM_HAL_DSI_FREQ_TRIM_X63
		am_hal_dsi_para_config(ui8LanesNum, ui8DbiWidth, ui32FreqTrim);
		#endif

		//
		// Enable QSPI Pins
		//
		am_bsp_disp_qspi_pins_enable();

		#if 0 // in vain
		//
		// Enable dc clock
		//
		nemadc_reg_write(NEMADC_REG_CLKCTRL_CG, NemaDC_clkctrl_cg_clk_en);
		#endif

		#if 0 // in vain
		//
		// Set clock divider. B2 and later versions of Apollo4 support setting DC primary clock divide ratio to 1.
		//
		if (APOLLO4_GE_B2)
		{
			nemadc_clkdiv(1, 1, 4, 0); // OK
		}
		else
		{
			nemadc_clkdiv(2, 1, 4, 0); // NG
		}
		#endif

		#if 0 // in vain
    //
    // Enable fast pixel generation slow transfer
    //
    if (APOLLO4_GE_B2)
    {
        nemadc_reg_write(NEMADC_REG_CLKCTRL_CG,
                        (NemaDC_clkctrl_cg_clk_swap |
                         NemaDC_clkctrl_cg_l0_bus_clk |
                         NemaDC_clkctrl_cg_clk_en));
    }
    else
    {
        nemadc_reg_write(NEMADC_REG_CLKCTRL_CG,
                        (NemaDC_clkctrl_cg_clk_swap |
                         NemaDC_clkctrl_cg_clk_en));
    }
		#endif

		#if 0 // in vain
		#define TB_LCDPANEL_MIPI_DBIB 14 // am_devices_dsi_rm67162.h
    nemadc_clkctrl((nemadc_clkctrl_t)TB_LCDPANEL_MIPI_DBIB);

    if (APOLLO4_GE_B2)
    {
        nemadc_MIPI_CFG_out(MIPICFG_DBI_EN          |
                            MIPICFG_RESX            |
                            MIPICFG_EXT_CTRL        |
                            MIPICFG_DIS_TE          |
                            MIPICFG_EN_STALL        |
                            MIPICFG_PIXCLK_OUT_EN);
    }
    else
    {
        nemadc_MIPI_CFG_out(MIPICFG_DBI_EN          |
                            MIPICFG_RESX            |
                            MIPICFG_EXT_CTRL        |
                            MIPICFG_DIS_TE          |
                            MIPICFG_PIXCLK_OUT_EN);

    }
		#endif

		//
		// Program NemaDC MIPI interface
		//
		nemadc_MIPI_CFG_out(mode | MIPICFG_SPI_CSX_V | MIPICFG_DBI_EN | MIPICFG_RESX | pixel_format | MIPICFG_DIS_TE);
		am_util_delay_ms(10);

		uint8_t cmd_buf[10];

		//
		// Sleep Out 0x11
		//
		send_MIPI_cmd(QSPI_MODE, 0x11, NULL, 0);
		//
		// Delay 120ms
		am_util_delay_ms(120);
		//
		// Write Tearing Effect Scan Line 0x44
		//
		cmd_buf[0]=(XMAX-1)>>8;
		cmd_buf[1]=(XMAX-1)%256;
		send_MIPI_cmd(QSPI_MODE, 0x44, cmd_buf, 2);
		//
		// Tearing Effect On 0x35
		//
		cmd_buf[0]=0x00;
		send_MIPI_cmd(QSPI_MODE, 0x35, cmd_buf, 1);
		//
		// Write Pixel Format 0x3A
		//
		cmd_buf[0]=0x55; // 0x55=16Bit, 0x77=24Bit
		send_MIPI_cmd(QSPI_MODE, 0x3A, cmd_buf, 1);
		//
		// Write CTRL Display 1 0x53
		//
		cmd_buf[0]=0x20; // 0x20=Brightness Control On
		send_MIPI_cmd(QSPI_MODE, 0x53, cmd_buf, 1);
		//
		// Memory Data Access Control 0x36
		//
		cmd_buf[0]=0x00; // 0x00=RGB16, 0x08=BGR16, 0x40 flip left to right
		send_MIPI_cmd(QSPI_MODE, 0x36, cmd_buf, 1);
		//
		// Write Display Brightness Value 0x51
		//
		cmd_buf[0]=0xFF; // [7:0]
		cmd_buf[1]=0x03; // [9:8]
		send_MIPI_cmd(QSPI_MODE, 0x51, cmd_buf, 2);
		//
		// Delay 25ms
		//
		am_util_delay_ms(25);
		//
		// Display On 0x29
		//
		send_MIPI_cmd(QSPI_MODE, 0x29, NULL, 0);
		//
		// Set Update Region to Full Screen
		//
		am_devices_nemadc_rm67162_set_region(QSPI_MODE, XMAX, YMAX, 0, 0);
		nemadc_timing(XMAX, 0, 0, 0, YMAX, 0, 0, 0);

		return 0;
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/






























/******************************************************************************/
/*                                                                            */
/* Send_frame_single_start                                                    */
/*                                                                            */
/******************************************************************************/
#if 0
void nemadc_send_frame_single_start(void)
{
    uint32_t dbi_cfg;
    nemadc_reg_write(NEMADC_REG_CLKCTRL_CG, 0xAA000000U); // disable clock gating
    switch (g_sDispCfg[g_eDispType].eInterface)
    {
        case IF_QSPI:
            dbi_cfg = nemadc_reg_read( NEMADC_REG_DBIB_CFG);
            nemadc_MIPI_CFG_out( dbi_cfg | MIPICFG_SPI_HOLD);
            nemadc_MIPI_out    ( MIPI_DBIB_CMD | MIPI_MASK_QSPI | CMD1_DATA4);
            nemadc_MIPI_out    ( MIPI_DBIB_CMD | MIPI_MASK_QSPI | MIPI_CMD24 |
                               (MIPI_write_memory_start << CMD_OFFSET));
            nemadc_reg_write(NEMADC_REG_INTERRUPT, 1 << 4); //!< Enable frame end interrupt
            nemadc_set_mode(NEMADC_ONE_FRAME);
            break;
        case IF_DSPI:
            dbi_cfg = nemadc_reg_read( NEMADC_REG_DBIB_CFG);
            nemadc_MIPI_CFG_out( dbi_cfg & (~MIPICFG_DSPI) & (~MIPICFG_QSPI));
            // Start MIPI Panel Memory Write
            nemadc_MIPI_out(MIPI_DBIB_CMD | MIPI_write_memory_start);
            nemadc_MIPI_CFG_out(((dbi_cfg & (~MIPICFG_SPI4)) | MIPICFG_SPI3)
                               | MIPICFG_SPIDC_DQSPI | MIPICFG_SPI_HOLD);
            nemadc_reg_write(NEMADC_REG_INTERRUPT, 1 << 4); //!< Enable frame end interrupt
            // Send One Frame
            nemadc_set_mode(NEMADC_ONE_FRAME);
            break;
        case IF_SPI4:
            // Start MIPI Panel Memory Write
            nemadc_MIPI_out(MIPI_DBIB_CMD | MIPI_write_memory_start);
            nemadc_reg_write(NEMADC_REG_INTERRUPT, 1 << 4); //!< Enable frame end interrupt
            // Send One Frame
            nemadc_set_mode(NEMADC_ONE_FRAME);
            break;
        default:
            break;
    }
}
#endif
/******************************************************************************/
/*                                                                            */
/* Send_frame_single_end                                                      */
/*                                                                            */
/******************************************************************************/
#if 0
void nemadc_send_frame_single_end(void)
{
    uint32_t dbi_cfg;

    switch (g_sDispCfg[g_eDispType].eInterface)
    {
        case IF_QSPI:
            dbi_cfg = nemadc_reg_read( NEMADC_REG_DBIB_CFG);
            nemadc_MIPI_CFG_out(dbi_cfg & (~MIPICFG_SPI_HOLD));
            break;
        case IF_DSPI:
            dbi_cfg = nemadc_reg_read( NEMADC_REG_DBIB_CFG);
            nemadc_MIPI_CFG_out((dbi_cfg | MIPICFG_SPI4) & (~MIPICFG_SPI3)
                               & (~MIPICFG_SPIDC_DQSPI) & (~MIPICFG_SPI_HOLD));
            break;
        default:
            break;
    }

    nemadc_reg_write(NEMADC_REG_CLKCTRL_CG, 0); // enable clock gating
}
#endif



















#if 0
void send_MIPI_cmd(uint8_t spi_mode, uint8_t cmd, uint8_t* data, uint8_t l)
{
    if (spi_mode == QSPI_MODE)
    {   //QSPI
        uint32_t dbi_cfg = nemadc_reg_read(NEMADC_REG_DBIB_CFG);
        nemadc_MIPI_CFG_out(dbi_cfg | MIPICFG_SPI_HOLD);
        nemadc_MIPI_out(MIPI_DBIB_CMD | MIPI_MASK_QSPI | CMD1_DATA1);
        nemadc_MIPI_out(MIPI_DBIB_CMD | MIPI_MASK_QSPI | MIPI_CMD24 | (cmd << CMD_OFFSET));
        for ( int i = 0; i < l; i++ )
        {
            nemadc_MIPI_out(MIPI_DBIB_CMD | MIPI_MASK_QSPI | data[i]);
        }
        nemadc_MIPI_CFG_out(dbi_cfg);
    }
    else if (spi_mode == DSPI_MODE)
    {   //DSPI
        uint32_t dbi_cfg = nemadc_reg_read(NEMADC_REG_DBIB_CFG);
        nemadc_MIPI_CFG_out(dbi_cfg & (~MIPICFG_DSPI) & (~MIPICFG_QSPI));
        nemadc_MIPI_out(MIPI_DBIB_CMD | cmd);
        for ( int i = 0; i < l; i++ )
        {
            nemadc_MIPI_out(data[i]);
        }
        nemadc_MIPI_CFG_out(dbi_cfg);
    }
    else
    {   //SPI4
        nemadc_MIPI_out(MIPI_DBIB_CMD | cmd);
        for ( int i = 0; i < l; i++ )
        {
            nemadc_MIPI_out(data[i]);
        }
    }
}
#endif



		#if 0
		uint16_t xofs=minx;
		uint16_t yofs=miny;
		uint16_t w=RESX;
		uint16_t h=RESY;
		//
		// Column Address Set 0x2A
		//
		cmd_buf[0]=(uint8_t)(xofs >> 8U);
		cmd_buf[1]=(uint8_t)(xofs  & 0xFFU); 
		cmd_buf[2]=(uint8_t)((xofs+w-1) >> 8U);
		cmd_buf[3]=(uint8_t)((xofs+w-1)  & 0xFFU);
		send_MIPI_cmd(QSPI_MODE, 0x2A, cmd_buf, 4);
		//
		// Page Address Set 0x2B
		//
		cmd_buf[0]=(uint8_t)(yofs >> 8U);
		cmd_buf[1]=(uint8_t)(yofs  & 0xFFU);
		cmd_buf[2]=(uint8_t)((yofs+h-1) >> 8U);
		cmd_buf[3]=(uint8_t)((yofs+h-1)  & 0xFFU);
		send_MIPI_cmd(QSPI_MODE, 0x2B, cmd_buf, 4);
		//
		// Program NemaDC to transfer a resx*resy region
		//
		// void nemadc_timing(int resx, int fpx, int blx, int bpx, 
		//                    int resy, int fpy, int bly, int bpy);
		// resx Resolution X
		// fpx  Front Porch X
		// blx  Blanking X
		// bpx  Back Porch X
		// resy Resolution Y
		// fpy  Front Porch Y
		// bly  Blanking Y
		// bpy  Back Porch Y
		//
		nemadc_timing(w, 1, 1, 1, h, 1, 1, 1);
		#endif



#if 0
void nemadc_send_frame_single(void)
{
    uint32_t dbi_cfg;
    nemadc_reg_write(NEMADC_REG_CLKCTRL_CG, 0xAA000000U); // disable clock gating
    switch (g_sDispCfg[g_eDispType].eInterface)
    {
        case IF_QSPI:
            dbi_cfg = nemadc_reg_read( NEMADC_REG_DBIB_CFG);
            nemadc_MIPI_CFG_out( dbi_cfg | MIPICFG_SPI_HOLD);
            nemadc_MIPI_out    ( MIPI_DBIB_CMD | MIPI_MASK_QSPI | CMD1_DATA4);
            nemadc_MIPI_out    ( MIPI_DBIB_CMD | MIPI_MASK_QSPI | MIPI_CMD24 |
                               (MIPI_write_memory_start << CMD_OFFSET));
            nemadc_reg_write(NEMADC_REG_INTERRUPT, 1 << 4); //!< Enable frame end interrupt
            nemadc_set_mode(NEMADC_ONE_FRAME);
            // Wait for transfer to be completed
            nemadc_wait_vsync();
            nemadc_MIPI_CFG_out(dbi_cfg);
            break;
        case IF_DSPI:
            dbi_cfg = nemadc_reg_read( NEMADC_REG_DBIB_CFG);
            nemadc_MIPI_CFG_out( dbi_cfg & (~MIPICFG_DSPI) & (~MIPICFG_QSPI));
            // Start MIPI Panel Memory Write
            nemadc_MIPI_out(MIPI_DBIB_CMD | MIPI_write_memory_start);
            nemadc_MIPI_CFG_out(((dbi_cfg & (~MIPICFG_SPI4)) | MIPICFG_SPI3)
                               | MIPICFG_SPIDC_DQSPI | MIPICFG_SPI_HOLD);
            nemadc_reg_write(NEMADC_REG_INTERRUPT, 1 << 4); //!< Enable frame end interrupt
            // Send One Frame
            nemadc_set_mode(NEMADC_ONE_FRAME);
            // Wait for transfer to be completed
            nemadc_wait_vsync();
            nemadc_MIPI_CFG_out(dbi_cfg);
            break;
        case IF_SPI4:
            // Start MIPI Panel Memory Write
            nemadc_MIPI_out(MIPI_DBIB_CMD | MIPI_write_memory_start);
            nemadc_reg_write(NEMADC_REG_INTERRUPT, 1 << 4); //!< Enable frame end interrupt
            // Send One Frame
            nemadc_set_mode(NEMADC_ONE_FRAME);
            // Wait for transfer to be completed
            nemadc_wait_vsync();
            break;
        default:
            ; // NOP
    }
    nemadc_reg_write(NEMADC_REG_CLKCTRL_CG, 0); // enable clock gating
}
#endif



		#if 0
		//
		// Program NemaDC to transfer a resx*resy region
		//
		// resx Resolution X
		// fpx  Front Porch X
		// blx  Blanking X
		// bpx  Back Porch X
		// resy Resolution Y
		// fpy  Front Porch Y
		// bly  Blanking Y
		// bpy  Back Porch Y
		//
		// void nemadc_timing(int resx, int fpx, int blx, int bpx, int resy, int fpy, int bly, int bpy);
		// nemadc_timing(resx, 4, 10, 10, resy, 10, 50, 10); // OK
		// nemadc_timing(resx, 1, 1, 1, resy, 1, 1, 1); // OK
		nemadc_timing(resx, 0, 0, 0, resy, 0, 0, 0); // OK
		#endif


#if 0
uint32_t am_devices_nemadc_rm67162_init(uint32_t mode, uint32_t pixel_format, uint16_t resx, uint16_t resy, uint16_t minx, uint16_t miny)
{
    uint8_t spi_mode;
    uint8_t cmd_buf[4];
    uint16_t maxx, maxy;

    if (g_eDispType == RM69330_QSPI)
    {
        #ifdef AM_BSP_DISPLAY_OFFSET
            minx += AM_BSP_DISPLAY_OFFSET; // To ajust Apollo4b_bga_evb_disp_shld offset
        #endif
    }

    maxx = minx + resx - 1;
    maxy = miny + resy - 1;

    if ( 0!=(mode&MIPICFG_QSPI) )
    {
        spi_mode = QSPI_MODE;
        am_bsp_disp_qspi_pins_enable();
    }
    else if ( 0!=(mode&MIPICFG_DSPI) )
    {
        spi_mode = DSPI_MODE;
        am_bsp_disp_dspi_pins_enable();
    }
    else
    {
        spi_mode = SPI4_MODE;
        am_bsp_disp_spi_pins_enable();
    }

    // hardware reset
    send_RESX_signal();

    // Program NemaDC MIPI interface
    nemadc_MIPI_CFG_out(mode | MIPICFG_SPI_CSX_V | MIPICFG_DBI_EN | MIPICFG_RESX | pixel_format | MIPICFG_DIS_TE);
    DELAY(10);

    // Enable/disable tearing
    send_MIPI_cmd(spi_mode, MIPI_set_tear_off, NULL, 0);
    DELAY(10);

    const int MIPI_set_dspi_mode = 0xc4;
    if (spi_mode == DSPI_MODE)
    {
        cmd_buf[0] = 0xA1; //enable DSPI 1P1T 2-Wire
    }
    else
    {
        cmd_buf[0] = 0x80;
    }
    send_MIPI_cmd(spi_mode, MIPI_set_dspi_mode, cmd_buf, 1);
    DELAY(10);

    // Set MIPI Panel Pixel Format
    cmd_buf[0] = (uint8_t)(pixel_format & 0x3f);
    send_MIPI_cmd(spi_mode, MIPI_set_pixel_format, cmd_buf, 1);
    DELAY(10);

    if (g_sDispCfg[g_eDispType].bFlip == true)
    {
        cmd_buf[0] = 0x02;
    }
    else
    {
        cmd_buf[0] = 0x00;
    }
    send_MIPI_cmd(spi_mode, MIPI_set_address_mode, cmd_buf, 1);
    DELAY(10);

    const int MIPI_set_wr_display_ctrl = 0x53;
    cmd_buf[0] = 0x20;
    send_MIPI_cmd(spi_mode, MIPI_set_wr_display_ctrl, cmd_buf, 1);
    DELAY(10);

    const int MIPI_set_display_brightness = 0x51;
    cmd_buf[0] = 0xff;      // write display brightness
    send_MIPI_cmd(spi_mode, MIPI_set_display_brightness, cmd_buf, 1);
    DELAY(10);

    cmd_buf[0] = 0x0;
    cmd_buf[1] = 0x28;
    send_MIPI_cmd(spi_mode, MIPI_set_tear_scanline, cmd_buf, 2);
    DELAY(10);

    // Enable MIPI Panel
    send_MIPI_cmd(spi_mode, MIPI_exit_sleep_mode, NULL, 0);
    DELAY(130);

    send_MIPI_cmd(spi_mode, MIPI_set_display_on, NULL, 0);
    DELAY(200);

    // Set MIPI Panel region to be updated
    cmd_buf[0] = (uint8_t)(minx >> 8U);
    cmd_buf[1] = (uint8_t)(minx  & 0xFFU);
    cmd_buf[2] = (uint8_t)(maxx >> 8U);
    cmd_buf[3] = (uint8_t)(maxx  & 0xFFU);
    send_MIPI_cmd(spi_mode, MIPI_set_column_address, cmd_buf, 4);

    cmd_buf[0] = (uint8_t)(miny >> 8U);
    cmd_buf[1] = (uint8_t)(miny  & 0xFFU);
    cmd_buf[2] = (uint8_t)(maxy >> 8U);
    cmd_buf[3] = (uint8_t)(maxy  & 0xFFU);
    send_MIPI_cmd(spi_mode, MIPI_set_page_address, cmd_buf, 4);
    // Program NemaDC to transfer a resx*resy region
    nemadc_timing(resx, 4, 10, 10,
                  resy, 10, 50, 10);

    return 0;
}
#endif




/******************************************************************************/
/*                                                                            */
/* send_reset_signal                                                           */
/*                                                                            */
/******************************************************************************/
#if 0
void send_RESX_signal(void)
{
    //
    // send display a reset
    //

    uint32_t ui32GpioNum;
    if (g_sDispCfg[g_eDispType].eInterface == IF_DSPI)
    {
        ui32GpioNum = AM_BSP_GPIO_DISP_DSPI_RES;
    }
    else if (g_sDispCfg[g_eDispType].eInterface == IF_QSPI)
    {
        ui32GpioNum = AM_BSP_GPIO_DISP_QSPI_RES;
    }
    else
    {
        ui32GpioNum = AM_BSP_GPIO_DISP_SPI_RES;
    }
    am_hal_gpio_pinconfig(ui32GpioNum,  am_hal_gpio_pincfg_output);
    am_hal_gpio_state_write(ui32GpioNum, AM_HAL_GPIO_OUTPUT_SET);
    DELAY(5);
    am_hal_gpio_state_write(ui32GpioNum, AM_HAL_GPIO_OUTPUT_CLEAR);
    DELAY(20);
    am_hal_gpio_state_write(ui32GpioNum, AM_HAL_GPIO_OUTPUT_SET);
    DELAY(150);
}
#endif