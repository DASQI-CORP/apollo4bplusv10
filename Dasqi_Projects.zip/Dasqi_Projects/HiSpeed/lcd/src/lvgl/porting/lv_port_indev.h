






#ifndef LV_PORT_INDEV_H
#define LV_PORT_INDEV_H
/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "lvgl.h"
#include "..\..\main.h"
#include "..\..\touch\touch.h"
/******************************************************************************/
/*                                                                            */
/* Global Variables and Defines                                               */
/*                                                                            */
/******************************************************************************/
extern lv_indev_drv_t indev_drv;
extern lv_indev_t *indev_touchpad;
/******************************************************************************/
extern Touch_T touch;
/******************************************************************************/
/*                                                                            */
/* Functions                                                                  */
/*                                                                            */
/******************************************************************************/
extern void lv_port_indev_init(void);
extern void touchpad_init(void);
extern void touchpad_get_xy(lv_coord_t *x, lv_coord_t *y);
extern bool touchpad_is_pressed(void);
extern void touchpad_read(lv_indev_drv_t *indev_drv, lv_indev_data_t *data);
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
#endif







