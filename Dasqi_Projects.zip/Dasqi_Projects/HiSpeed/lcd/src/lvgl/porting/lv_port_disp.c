









/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\..\main.h"
#include "lv_port_disp.h"
#include "..\..\sh8601\sh8601.h"
#include "..\..\am_devices_nemadc_rm67162\am_devices_nemadc_rm67162.h"
#include "..\asset\STARTUP_LOGO_372x71_P.c"
/******************************************************************************/
#include "nema_core.h"
#include "nema_utils.h"
#include "nema_regs.h"
/******************************************************************************/
/*                                                                            */
/* Global Variables and Defines                                               */
/*                                                                            */
/******************************************************************************/
#define FRAMEBUFFER_NUM 2
/******************************************************************************/
#ifdef USE_MSPI
img_obj_t g_nemaFB[FRAMEBUFFER_NUM];
uint16_t *g_pFrameBuffer[FRAMEBUFFER_NUM];
#endif
/******************************************************************************/
#ifdef USE_NEMADC

#define OPT 1

#if (OPT==0)
img_obj_t fb;
nemadc_layer_t layer= {0};
#endif

#if (OPT==1)
img_obj_t fb[FRAMEBUFFER_NUM];
nemadc_layer_t layer[FRAMEBUFFER_NUM]= {{0}};
#endif

#endif
/******************************************************************************/
// nema_cmdlist_t nemaCL;
/******************************************************************************/
/*                                                                            */
/* init_NEMA_framebuffer                                                      */
/*                                                                            */
/******************************************************************************/
void init_NEMA_framebuffer(void)
{
		#ifdef USE_MSPI
		for(uint32_t i = 0; i < FRAMEBUFFER_NUM; i++)
		{
			g_nemaFB[i].bo = nema_buffer_create(XMAX * YMAX * 2);
			memset((void*)(g_nemaFB[i].bo.base_phys), 0, XMAX * YMAX * 2);
			g_nemaFB[i].w = XMAX;
			g_nemaFB[i].h = YMAX;
			g_nemaFB[i].color = 0;
			g_nemaFB[i].sampling_mode = 0;
			g_nemaFB[i].format = NEMA_RGB565;
			g_nemaFB[i].stride = nema_format_size(g_nemaFB[i].format) * XMAX;
			g_pFrameBuffer[i] = (uint16_t *)g_nemaFB[i].bo.base_phys;
		}
		#endif

		#ifdef USE_NEMADC

		#if (OPT==0)
		fb.stride = nema_stride_size(NEMA_RGB565, 0, XMAX); // stride=2*XMAX
		fb.w = XMAX;
		fb.h = YMAX;
		fb.format = NEMA_RGB565;
		fb.bo = nema_buffer_create(fb.stride*fb.h);

		layer.sizex = layer.resx = fb.w;
		layer.sizey = layer.resy = fb.h;
		layer.stride = -1;
		layer.format = NEMADC_RGB565;
		layer.blendmode = NEMADC_BL_SRC;
		layer.baseaddr_phys = fb.bo.base_phys;
		layer.baseaddr_virt = fb.bo.base_virt;
		//
		// Enable Layer and set attributes to it, this is a must
		//
		nemadc_set_layer(0, &layer);
		#endif

		#if (OPT==1)
		for(uint32_t i = 0; i < FRAMEBUFFER_NUM; i++)
		{
			fb[i].stride = nema_stride_size(NEMA_RGB565, 0, XMAX); // stride=2*XMAX
			fb[i].w = XMAX;
			fb[i].h = YMAX;
			fb[i].format = NEMA_RGB565;
			fb[i].bo = nema_buffer_create(fb[i].stride*fb[i].h);

			layer[i].sizex = layer[i].resx = fb[i].w;
			layer[i].sizey = layer[i].resy = fb[i].h;
			layer[i].stride = -1;
			layer[i].format = NEMADC_RGB565;
			layer[i].blendmode = NEMADC_BL_SRC;
			layer[i].baseaddr_phys = fb[i].bo.base_phys;
			layer[i].baseaddr_virt = fb[i].bo.base_virt;
			//
			// Enable Layer and set attributes to it, this is a must
			//
			// nemadc_set_layer(0, &layer[i]);
		}

		nemadc_set_layer(0, &layer[0]);
		#endif



		#endif
}
/******************************************************************************/
/*                                                                            */
/* deinit_NEMA_framebuffer                                                    */
/*                                                                            */
/******************************************************************************/
#if 0
void deinit_NEMA_framebuffer(void)
{
	for(uint32_t i = 0; i < FRAMEBUFFER_NUM; i++)
	{
		nema_buffer_destroy(&g_nemaFB[i].bo);
	}
}
#endif
/******************************************************************************/
/*                                                                            */
/* disp_init                                                                  */
/*                                                                            */
/******************************************************************************/
void disp_init(void){}
/******************************************************************************/
/*                                                                            */
/* Display Logo                                                               */
/*                                                                            */
/******************************************************************************/
void Disp_Logo(void)
{
		#ifdef USE_MSPI
		lv_area_t area;
		area.x1=0;
		area.x2=XMAX-1;
		uint16_t c[XMAX];
		for(int i=0; i<XMAX; i++)c[i]=0xFFFF;
		for(int i=0; i<YMAX; i++)
		{
			area.y1=area.y2=i;
			sh8601_mspi_set_transfer_window((lv_area_t*)&area);
			sh8601_mspi_nonblocking_write((uint8_t*)c, XMAX*2, true);
		}
		area.x1=(XMAX-STARTUP_LOGO_372x71_P.header.w)/2;
		area.y1=(YMAX-STARTUP_LOGO_372x71_P.header.h)/2;
		area.x2=area.x1+STARTUP_LOGO_372x71_P.header.w-1;
		area.y2=area.y1+STARTUP_LOGO_372x71_P.header.h-1;
		uint32_t w=(area.x2-area.x1)+1;
		uint32_t h=(area.y2-area.y1)+1;
		sh8601_mspi_set_transfer_window((lv_area_t*)&area);
		sh8601_mspi_nonblocking_write((uint8_t*)STARTUP_LOGO_372x71_P_map, w*h*2, true);
		am_util_delay_ms(1000);
		#endif

		#ifdef USE_NEMADC
		img_obj_t f;
		f.stride = nema_stride_size(NEMA_RGB565, 0, XMAX);
		f.w = XMAX;
		f.h = YMAX;
		f.format = NEMA_RGB565;
		f.bo = nema_buffer_create(f.stride*f.h);
		nema_buffer_map(&f.bo);

		nemadc_layer_t layer= {0};
		layer.sizex = layer.resx = f.w;
		layer.sizey = layer.resy = f.h;
		layer.stride = -1;
		layer.format = NEMADC_RGB565;
		layer.blendmode = NEMADC_BL_SRC;
		layer.baseaddr_phys = f.bo.base_phys;
		layer.baseaddr_virt = f.bo.base_virt;
		nemadc_set_layer(0, &layer);

		uint16_t *p16=(uint16_t*)layer.baseaddr_phys;
		for(uint32_t i=0; i<(layer.resx*layer.resy); i++)p16[i]=0xFFFF;
		am_devices_nemadc_rm67162_set_region(QSPI_MODE, XMAX, YMAX, 0, 0);
		nemadc_timing(XMAX, 0, 0, 0, YMAX, 0, 0, 0);
		nemadc_send_frame_single();

		uint8_t *p8=(uint8_t*)layer.baseaddr_phys;
		uint32_t w=STARTUP_LOGO_372x71_P.header.w;
		uint32_t h=STARTUP_LOGO_372x71_P.header.h;
		uint32_t xofs=(XMAX-w)/2;
		uint32_t yofs=(YMAX-h)/2;
		for(uint32_t i=0; i<(w*h*2); i++)p8[i]=STARTUP_LOGO_372x71_P_map[i];

		am_devices_nemadc_rm67162_set_region(QSPI_MODE, w, h, xofs, yofs);
		nemadc_timing(w, 0, 0, 0, h, 0, 0, 0);
		nemadc_send_frame_single();

		nema_buffer_destroy(&f.bo);

		am_util_delay_ms(1000);

		am_devices_nemadc_rm67162_set_region(QSPI_MODE, XMAX, YMAX, 0, 0);
		nemadc_timing(XMAX, 0, 0, 0, YMAX, 0, 0, 0);

		#endif
}
/******************************************************************************/
/*                                                                            */
/* lv_port_disp_init                                                          */
/*                                                                            */
/******************************************************************************/
void lv_port_disp_init(void)
{
		Disp_Logo();

		init_NEMA_framebuffer();

		disp_init();

		static lv_disp_draw_buf_t draw_buf_dsc_1;

		#ifdef USE_MSPI
		lv_disp_draw_buf_init(&draw_buf_dsc_1, g_pFrameBuffer[0] , g_pFrameBuffer[1], XMAX * YMAX);
		#endif

		#ifdef USE_NEMADC
		#if (OPT==0)
		lv_disp_draw_buf_init(&draw_buf_dsc_1, (uint8_t*)fb.bo.base_phys, NULL, XMAX * YMAX);
		#endif
		#if (OPT==1)
		lv_disp_draw_buf_init(&draw_buf_dsc_1, (uint8_t*)fb[0].bo.base_phys, (uint8_t*)fb[1].bo.base_phys, XMAX * YMAX);
		#endif
		#endif

		static lv_disp_drv_t disp_drv;
		lv_disp_drv_init(&disp_drv);

		disp_drv.hor_res = XMAX;
		disp_drv.ver_res = YMAX;
		disp_drv.physical_hor_res=-1; // -1 for fullscreen mode
		disp_drv.physical_ver_res=-1; // -1 for fullscreen mode
		disp_drv.offset_x=0;
		disp_drv.offset_y=0;
		disp_drv.sw_rotate=1;
		disp_drv.rotated=LV_DISP_ROT_180; // LV_DISP_ROT_NONE, LV_DISP_ROT_90, LV_DISP_ROT_180, LV_DISP_ROT_270
		disp_drv.antialiasing=0;
		disp_drv.screen_transp=0;

		disp_drv.flush_cb = disp_flush;
		disp_drv.draw_buf = &draw_buf_dsc_1;

		lv_disp_drv_register(&disp_drv);
}
/******************************************************************************/
/*                                                                            */
/* swap16                                                                     */
/*                                                                            */
/******************************************************************************/
inline uint16_t swap16(uint16_t t)
{
		return (uint16_t)((t<<8)|(t>>8));
}
/******************************************************************************/
/*                                                                            */
/* rev16                                                                     */
/*                                                                            */
/******************************************************************************/
inline uint32_t rev16(uint32_t a)
{
		__ASM("rev16 a, a");
		return a;
}
/******************************************************************************/
/*                                                                            */
/* disp_flush                                                                 */
/*                                                                            */
/******************************************************************************/
void disp_flush(lv_disp_drv_t *disp_drv, const lv_area_t *area, lv_color_t *color_p)
{
		#ifdef USE_MSPI
		uint32_t w=(area->x2-area->x1)+1;
		uint32_t h=(area->y2-area->y1)+1;
		sh8601_mspi_set_transfer_window((lv_area_t *)area);
		sh8601_mspi_nonblocking_write((uint8_t*)color_p, w*h*2, true);
		#endif

		#ifdef USE_NEMADC

		#if (OPT==0)
		#if 0
		uint32_t xofs=area->x1;
		uint32_t yofs=area->y1;
		uint32_t w=(area->x2-area->x1)+1;
		uint32_t h=(area->y2-area->y1)+1;
		am_devices_nemadc_rm67162_set_region(QSPI_MODE, w, h, xofs, yofs);
		nemadc_timing(w, 0, 0, 0, h, 0, 0, 0);

		uint16_t *c=(uint16_t*)color_p;
		uint16_t *p=(uint16_t*)fb.bo.base_phys;
		for(uint32_t i=0; i<(w*h); i++)
		{
			p[i]=swap16(c[i]);
		}
		nemadc_send_frame_single();
		#endif

		#if 0
		uint32_t w=(area->x2-area->x1)+1;
		uint32_t h=(area->y2-area->y1)+1;
		am_devices_nemadc_rm67162_set_region(QSPI_MODE, w, h, area->x1, area->y1);
		nemadc_timing(w, 0, 0, 0, h, 0, 0, 0);

		uint32_t *c=(uint32_t*)color_p;
		uint32_t *p=(uint32_t*)fb.bo.base_phys;
		for(uint32_t i=0; i<(w*h/2); i++)
		{
			#if (LV_COLOR_16_SWAP==1) // C:\Keil_v5\ARM\PACK\lvgl_8_3\lv_conf.h
			// __ASM("rev16 p[i], c[i]");
			#else
			p[i]=c[i];
			#endif
		}
		nemadc_send_frame_single();
		#endif


		#if 1
		uint32_t w=(area->x2-area->x1)+1;
		uint32_t h=(area->y2-area->y1)+1;
		am_devices_nemadc_rm67162_set_region(QSPI_MODE, w, h, area->x1, area->y1);
		nemadc_timing(w, 0, 0, 0, h, 0, 0, 0);
		nemadc_send_frame_single();
		#endif
		#endif

		#if (OPT==1)
		uint32_t w=(area->x2-area->x1)+1;
		uint32_t h=(area->y2-area->y1)+1;
		am_devices_nemadc_rm67162_set_region(QSPI_MODE, w, h, area->x1, area->y1);
		nemadc_timing(w, 0, 0, 0, h, 0, 0, 0);
		nemadc_send_frame_single();
		#endif

		#endif




		lv_disp_flush_ready(disp_drv);
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/















