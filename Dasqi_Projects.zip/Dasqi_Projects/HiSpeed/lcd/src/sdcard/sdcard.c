





/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "sdcard.h"
#include "..\sdcard_sdio\sdcard_sdio.h"
#include "..\sdcard_disk\Sdcard_disk.h"
#include "..\sdcard_rw_test\sdcard_rw_test.h"
#include "..\sdcard_file_test\sdcard_file_test.h"
#include "..\wave\wave.h"
#include "..\openwave\openwave.h"
#include "..\i2s\i2s.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
int iSDCARD_Error=0;
/******************************************************************************/
/*                                                                            */
/* init sdcard                                                                */
/*                                                                            */
/******************************************************************************/
void Change_SDIO_IO_Type(void)
{
		uint8_t sdioBuf512[512];
		for(int i=0; i<512; i++)sdioBuf512[i]=0x00;
		mmc_disk_write(sdioBuf512, eMMCard.ui32MaxBlks-1, 1);
}
/******************************************************************************/
/*                                                                            */
/* init sdcard                                                                */
/*                                                                            */
/******************************************************************************/
void sdcard_test(void)
{
		//
		// sdio RW test
		//
		#if 0
		sdio_rw_test(1, 0x02);
		#endif
		//
		// FatFs test
		//
		#if 0
		file_rw_test();
		#endif
		//
		// Open Wave file
		//
		#if 1
		Change_SDIO_IO_Type();

		res = f_mount(&eMMCFatFs, (TCHAR const*)eMMCPath, 0);
		if(res!=FR_OK)
		{
			am_util_stdio_printf("Mount FatFs Fail\n"); 
			return;
		}
		am_util_stdio_printf("Mount FatFs OK\n");

		res=f_open(&fWave, "Go.wav", FA_READ);
		if(res!=FR_OK)
		{
			am_util_stdio_printf("Fail to Open file for Read\n");
			return;
		}
		#if SDCARD_PRINT
		am_util_stdio_printf("File is Opened for Read OK\n");
		#endif

		if(openwave(&fWave)!=GOODEC)
		{
			am_util_stdio_printf("Fail to Open Wave file\n");
			return;
		}
		#if SDCARD_PRINT
		am_util_stdio_printf("Wave File is Opened for Read OK\n");
		am_util_stdio_printf("fWave.obj.objsize=%u\n", fWave.obj.objsize);
		am_util_stdio_printf("fWave.fptr=%u\n", fWave.fptr);
		#endif

		#if 1
		uint16_t data;
		uint32_t i=0;
		uint32_t j=0;
		uint32_t read_cnt;
		for(j=0; j<256; j++)
		{
			am_util_stdio_printf("\nj=%d", j);
			for(i=0; i<256; i++)
			{
				if((i%16)==0)am_util_stdio_printf("\n");
				if(f_read(&fWave, (uint8_t*)&data, 2, (UINT*)&read_cnt)!=FR_OK)
				{
					am_util_stdio_printf("f_read Error at j=%d i=%d\n", j, i);
					return;
				}
				am_util_stdio_printf("%04X ", data);
			}
			am_util_stdio_printf("\n");
		}
		#endif

		#if 0
		uint16_t data;
		uint32_t i=0;
		uint32_t j=0;
		uint32_t read_cnt;
		while(!f_eof(&fWave))
		// while(fWave.obj.objsize>fWave.fptr)
		{
			am_util_stdio_printf("j=%d\n", j++);
			for(i=0; i<256; i++)
			{
				if(f_read(&fWave, (uint8_t*)&data, 2, (UINT*)&read_cnt)!=FR_OK)
				{
					am_util_stdio_printf("f_read Error at j=%d i=%d\n", j, i);
					return;
				}
			}
		}
		#endif

		#endif


		#if 0 // Never Close
		res=f_close(&fWave);
		if(res!=FR_OK)
		{
			am_util_stdio_printf("Fail to Close File\n");
			return;
		}
		#if SDCARD_PRINT
		am_util_stdio_printf("Close File OK\n");
		#endif
		#endif
}
/******************************************************************************/
/*                                                                            */
/* init sdcard                                                                */
/*                                                                            */
/******************************************************************************/
void Open_WaveFile(const char *fname)
{
		//
		// Open Wave file
		//
		res=f_open(&fWave, fname, FA_READ);
		if(res!=FR_OK)
		{
			am_util_stdio_printf("Fail to Open file for Read\n");
			return;
		}
		#if SDCARD_PRINT
		am_util_stdio_printf("File is Opened for Read OK\n");
		#endif

		if(openwave(&fWave)!=GOODEC)
		{
			am_util_stdio_printf("Fail to Open Wave file\n");
			return;
		}
		#if SDCARD_PRINT
		am_util_stdio_printf("Wave File is Opened for Read OK\n");
		am_util_stdio_printf("fWave.obj.objsize=%u\n", fWave.obj.objsize);
		am_util_stdio_printf("fWave.fptr=%u\n", fWave.fptr);
		#endif
}
/******************************************************************************/
/*                                                                            */
/* init sdcard                                                                */
/*                                                                            */
/******************************************************************************/
int init_sdcard(void)
{
		//
		// Configure SDIO PINs.
		//
		#ifdef SDIO_WIDTH_1
		am_bsp_sdio_pins_enable(AM_HAL_HOST_BUS_WIDTH_1);
		#endif
		#ifdef SDIO_WIDTH_4
		am_bsp_sdio_pins_enable(AM_HAL_HOST_BUS_WIDTH_4);
		#endif
		//
		// mmc_disk_initialize.
		//
		if(mmc_disk_initialize()!=0)return -1;
		//
		// Self Test
		//
		#if 0
		sdcard_test();
		#endif
		//
		// Mount File System
		//
		#if 1
		Change_SDIO_IO_Type();
		#endif
		//
		// mount FatFs
		//
		res = f_mount(&eMMCFatFs, (TCHAR const*)eMMCPath, 0);
		if(res!=FR_OK)
		{
			am_util_stdio_printf("Mount FatFs Fail\n"); 
			return -1;
		}
		else
		{
			#if SDCARD_PRINT
			am_util_stdio_printf("Mount FatFs OK\n");
			#endif
			return 0;
		}
}
/******************************************************************************/
/*                                                                            */
/* TASK SDCard                                                                */
/*                                                                            */
/******************************************************************************/
void TASK_SDCard(void)
{
		static bool init=false;
		static volatile uint32_t t0;

		if(!init)
		{
			init=true;
			t0=msec;

			#if 0
			am_hal_pwrctrl_periph_enable(AM_HAL_PWRCTRL_PERIPH_SDIO); // Seems not necessary
			#endif


			for(int i=0; i<2; i++) // initial twice for pass power on reset
			{
				iSDCARD_Error=init_sdcard();
			}

			if(iSDCARD_Error==0)
			{
				//
				// Start Play
				//
				bStopSong=false;
				bNextSongBtnPressed=false;
				player=0;
				Open_WaveFile(playlist[player]);
				i2s_init_data();
				i2s_init();
			}
		}
		else
		{
			if(iSDCARD_Error==0)
			{
				if(bNextSongBtnPressed)
				{
					bNextSongBtnPressed=false;
					NVIC_DisableIRQ(i2s_interrupts[I2S_MODULE_0]);
					f_close(&fWave);
					player++;
					player%=SONGS;
					Open_WaveFile(playlist[player]);
					i2s_init_data();
					NVIC_EnableIRQ(i2s_interrupts[I2S_MODULE_0]);
				}
			}
		}
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/





