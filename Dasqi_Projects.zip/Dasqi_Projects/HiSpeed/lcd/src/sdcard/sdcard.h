




#ifndef _SDCARD_H
#define _SDCARD_H
/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\main.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
// #define SDIO_WIDTH_1
#define SDIO_WIDTH_4
/******************************************************************************/
// #define SDIO_BUS_SPEED 1000000 // NG
// #define SDIO_BUS_SPEED 16000000 // OK
// #define SDIO_BUS_SPEED 23000000 // OK
// #define SDIO_BUS_SPEED 25000000 // OK <--
// #define SDIO_BUS_SPEED 33000000 // OK
#define SDIO_BUS_SPEED 48000000 // OK
// #define SDIO_BUS_SPEED 96000000 // OK
// #define SDIO_BUS_SPEED 192000000 // OK
// #define SDIO_BUS_SPEED 384000000 // OK
/******************************************************************************/
#define SDCARD_PRINT 1
/******************************************************************************/
extern uint32_t MaxSectors;
extern int iSDCARD_Error;
/******************************************************************************/
extern void Change_SDIO_IO_Type(void);
extern void sdcard_test(void);
extern int init_sdcard(void);
extern void TASK_SDCard(void);
/******************************************************************************/
#endif




