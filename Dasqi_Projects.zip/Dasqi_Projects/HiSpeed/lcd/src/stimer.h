


#ifndef _STIMER_H
#define _STIMER_H
/******************************************************************************/
#include <stdint.h>
#include <stdbool.h>
/******************************************************************************/
#include "am_mcu_apollo.h"
#include "am_bsp.h"
#include "am_util.h"
/******************************************************************************/
#define WAKE_INTERVAL_C_IN_MS (1)
#define XT_PERIOD 32768
#define WAKE_INTERVAL_C (XT_PERIOD*WAKE_INTERVAL_C_IN_MS/1000)
/******************************************************************************/
extern volatile uint32_t msec;
/******************************************************************************/
extern void am_stimer_cmpr2_isr(void);
extern void stimer_init(void);
/******************************************************************************/
#endif



