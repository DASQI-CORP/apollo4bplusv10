



#ifndef _SDCARD_DISK_H
#define _SDCARD_DISK_H
/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\main.h"
#include "..\sdcard_sdio\sdcard_sdio.h"
#include "..\FatFs\ff.h"
#include "..\FatFs\diskio.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
#define SDCARD_DISK_PRINT 0
/******************************************************************************/
extern volatile DSTATUS Stat;
extern volatile bool bAsyncWriteIsDone;
extern volatile bool bAsyncReadIsDone;
/******************************************************************************/
/*                                                                            */
/* Functions                                                                  */
/*                                                                            */
/******************************************************************************/
extern DSTATUS mmc_disk_initialize (void);
extern DSTATUS mmc_disk_status (void);
extern DRESULT mmc_disk_read (BYTE* buff, LBA_t sector, UINT count);
extern DRESULT mmc_disk_write (const BYTE* buff, LBA_t sector, UINT count);
extern DRESULT mmc_disk_ioctl (BYTE cmd, void* buff);
/******************************************************************************/
#endif





