









/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "sdcard_disk.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
volatile DSTATUS Stat = STA_NOINIT;
volatile bool bAsyncWriteIsDone = false;
volatile bool bAsyncReadIsDone  = false;
/******************************************************************************/
//
// Interrupt handler for SDIO
//
/******************************************************************************/
void am_sdio_isr(void)
{
		uint32_t ui32IntStatus;

		am_hal_sdhc_intr_status_get(pSdhcCardHost->pHandle, &ui32IntStatus, true);
		am_hal_sdhc_intr_status_clear(pSdhcCardHost->pHandle, ui32IntStatus);
		am_hal_sdhc_interrupt_service(pSdhcCardHost->pHandle, ui32IntStatus);
}
/******************************************************************************/
//
// Card event call back function
//
/******************************************************************************/
void am_hal_card_event_test_cb(am_hal_host_evt_t *pEvt)
{
		am_hal_card_host_t *pHost = (am_hal_card_host_t *)pEvt->pCtx;

		if (AM_HAL_EVT_XFER_COMPLETE == pEvt->eType &&
				pHost->AsyncCmdData.dir == AM_HAL_DATA_DIR_READ)
		{
				bAsyncReadIsDone = true;
				#if 0
				am_util_stdio_printf("Last Read Xfered block %d\n", pEvt->ui32BlkCnt);
				#endif
		}

		if (AM_HAL_EVT_XFER_COMPLETE == pEvt->eType && pHost->AsyncCmdData.dir == AM_HAL_DATA_DIR_WRITE)
		{
				bAsyncWriteIsDone = true;
				#if 0
				am_util_stdio_printf("Last Write Xfered block %d\n", pEvt->ui32BlkCnt);
				#endif
		}

		if (AM_HAL_EVT_SDMA_DONE == pEvt->eType &&
				pHost->AsyncCmdData.dir == AM_HAL_DATA_DIR_READ)
		{
				#if 0
				am_util_debug_printf("SDMA Read Xfered block %d\n", pEvt->ui32BlkCnt);
				#endif
		}

		if (AM_HAL_EVT_SDMA_DONE == pEvt->eType &&
				pHost->AsyncCmdData.dir == AM_HAL_DATA_DIR_WRITE)
		{
				#if 0
				am_util_debug_printf("SDMA Write Xfered block %d\n", pEvt->ui32BlkCnt);
				#endif
		}

		if (AM_HAL_EVT_CARD_PRESENT == pEvt->eType)
		{
				am_util_debug_printf("A card is inserted\n");
		}
}
/******************************************************************************/
/*                                                                            */
/* Get Disk Status                                                            */
/*                                                                            */
/******************************************************************************/
DSTATUS mmc_disk_status (void)
{
		return Stat;
}
/******************************************************************************/
/*                                                                            */
/* Read Sector(s)                                                             */
/*                                                                            */
/******************************************************************************/
DRESULT mmc_disk_read(BYTE *buff, LBA_t sector, UINT count)
{
		DWORD ui32Status;

		//
		// Calling Read API
		//
		bAsyncReadIsDone=false;
		ui32Status=_am_hal_card_block_read_async(&eMMCard, sector, count, (uint8_t *)buff);
		if(ui32Status!=AM_HAL_STATUS_SUCCESS)
		{
			am_util_debug_printf("Fail to call read API. Read Status = %d\n", ui32Status);
			return RES_ERROR;
		}


		//
		// wait until the async read is done
		//
		DWORD i=0;
		while(!bAsyncReadIsDone)
		{
			am_util_delay_ms(1);
			i++;
			if(i==1000 )
			{
				am_util_debug_printf("Read Timeout\n");
				return RES_ERROR;
			}
		}

		return RES_OK;
}
/******************************************************************************/
/*                                                                            */
/* Write Sector(s)                                                            */
/*                                                                            */
/******************************************************************************/
DRESULT mmc_disk_write(const BYTE *buff, LBA_t sector, UINT count)
{
		BYTE * wr_buf;
		DWORD i = 0;
		DWORD ui32Status;

		wr_buf = (BYTE *)buff;
		//
		// Calling Write API
		//
		bAsyncWriteIsDone=false;
		ui32Status=_am_hal_card_block_write_async(&eMMCard, sector, count, (uint8_t *)wr_buf);
		if(ui32Status!=AM_HAL_STATUS_SUCCESS)
		{
				am_util_debug_printf("Fail to call write API. Write Status = %d\n", ui32Status);
				return RES_ERROR;
		}
		//
		// wait until the async write is done
		//
		while(!bAsyncWriteIsDone)
		{
			am_util_delay_ms(1);
			i++;
			if(i==1000)
			{
				am_util_debug_printf("Write Timeout\n");
				return RES_ERROR;
			}
		}

		return RES_OK;
}
/******************************************************************************/
/*                                                                            */
/* Miscellaneous Functions                                                    */
/*                                                                            */
/******************************************************************************/
DRESULT mmc_disk_ioctl 
(
		BYTE cmd,
		void *buff
)
{
		DRESULT res = RES_ERROR;

		if (Stat & STA_NOINIT)
		{
				return RES_NOTRDY;
		}

		switch (cmd)
		{
				case CTRL_SYNC :
						res = RES_OK;
						break;
				case GET_SECTOR_COUNT :
						*(uint32_t*)buff = MaxSectors;
						res = RES_OK;
						break;
				case GET_BLOCK_SIZE :
						*(uint32_t*)buff = 1;
						res = RES_OK;
						break;
				default:
						res = RES_PARERR;
		}
		return res;
}
/******************************************************************************/
/*                                                                            */
/* mmc_disk_initialize                                                        */
/*                                                                            */
/******************************************************************************/
DSTATUS mmc_disk_initialize(void)
{
		#if SDCARD_DISK_PRINT
		am_util_stdio_printf("mmc_disk_initialize();\n");
		#endif

		DWORD i=0;

		if(Stat==STA_NOINIT)
		{
				//
				// Get the SDHC card host instance
				//
				pSdhcCardHost = am_hal_get_card_host(AM_HAL_SDHC_CARD_HOST, true);
				if (pSdhcCardHost == NULL)
				{
						am_util_debug_printf("Error: No card host found!\n");
						Stat |= STA_NOINIT;
						return Stat;
				}
				//
				// check if card is present
				//
				i=0;
				while(_am_hal_card_host_find_card(pSdhcCardHost, &eMMCard)!=AM_HAL_STATUS_SUCCESS)
				{
					am_util_debug_printf("No card is present now\n");
					am_util_delay_ms(10);
					am_util_debug_printf("Checking if card is available again\n");
					i++;
					if(i==100)
					{
						Stat |= STA_NOINIT;
						return Stat;
					}
				}
				//
				// Initialize the card
				//
				i=0;
				while(_am_hal_card_init(&eMMCard, NULL, AM_HAL_CARD_PWR_CTRL_SDHC_OFF) != AM_HAL_STATUS_SUCCESS)
				{
					am_util_delay_ms(10);
					am_util_debug_printf("card and host is not ready, try again\n");
					i++;
					if(i==3)
					{
						Stat |= STA_NOINIT;
						return Stat;
					}
				}
				//
				// Set ADMA transfer mode
				//
				am_hal_card_host_set_xfer_mode(pSdhcCardHost, AM_HAL_HOST_XFER_ADMA);
				//
				// Async read & write, card insert & remove needs a callback function
				//
				am_hal_card_register_evt_callback(&eMMCard, am_hal_card_event_test_cb);

			Stat &= ~STA_NOINIT;
		}

		return Stat;
}
/******************************************************************************/




