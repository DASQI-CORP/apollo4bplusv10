




/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "openwave.h"
/******************************************************************************/
/*                                                                            */
/* print_each_chunk_header                                                    */
/*                                                                            */
/******************************************************************************/
int print_each_chunk_header(FIL *pFile, WAVE_HEADER header)
{
		FRESULT res;
		uint32_t read_cnt;

		uint32_t num_of_samples=(8*header.data_size)/(header.channels*header.bits_per_sample);
		uint32_t size_of_each_sample = (header.channels * header.bits_per_sample)/8;
		uint32_t bytes_in_each_channel=(size_of_each_sample/header.channels);
		int32_t low_limit;
		int32_t high_limit;
		int32_t signed_data_in_channel;

		uint8_t data_buffer[4]; // 4=size_of_each_sample

		#if OPENWAVE_PRINT
		am_util_stdio_printf("size_of_each_sample = %d\n", size_of_each_sample); // 4
		am_util_stdio_printf("bits_per_sample = %d\n", header.bits_per_sample); // 16
		#endif

		switch (header.bits_per_sample) 
		{
			case 8:
						low_limit=-128; // -0x80
						high_limit=127; // 0x80-1
						break;
			case 16:
						low_limit=-32768; // -0x8000
						high_limit=32767; // 0x8000-1
						break;
			case 32:
						low_limit=-2147483648; // -0x80000000
						high_limit=2147483647; // 0x80000000-1
						break;
			default:
						low_limit=-1;
						high_limit=1;
						break;
		}
		#if OPENWAVE_PRINT
		am_util_stdio_printf("bits_per_sample = %d, low_limit = %d, high_limit = %d\n", header.bits_per_sample, low_limit, high_limit);
		#endif

		for(uint32_t i=1; i<=num_of_samples; i++) // 6
		{

			res=f_read(pFile, data_buffer, sizeof(data_buffer), (UINT*)&read_cnt); // 4 Bytes

			if(res==FR_OK) 
			{
				uint16_t xchannels;
				uint32_t data_in_channel=0;
				uint32_t offset=0;
	
				for(xchannels=0; xchannels<header.channels; xchannels++ ) // 2
				{
					if(bytes_in_each_channel==4) 
					{
						data_in_channel=(data_buffer[offset+0]<<0)|(data_buffer[offset+1]<<8)|(data_buffer[offset+2]<<16)|(data_buffer[offset+3]<<24);
						signed_data_in_channel=(int32_t)data_in_channel;
					}
					else if(bytes_in_each_channel==2) 
					{
						data_in_channel=(data_buffer[offset+0]<<0)|(data_buffer[offset+1]<<8);
						signed_data_in_channel=(int32_t)data_in_channel;
					}
					else if(bytes_in_each_channel==1) 
					{
						data_in_channel=data_buffer[offset];
						signed_data_in_channel=(int32_t)data_in_channel;
						signed_data_in_channel-=128;
					}
					#if OPENWAVE_PRINT
					am_util_stdio_printf("Sample %ld/%ld Channel %d %ld\n", i, num_of_samples, xchannels+1, signed_data_in_channel);
					#endif

					if((signed_data_in_channel<low_limit)||(signed_data_in_channel>high_limit))
					{
						am_util_stdio_printf("Sample %ld/%ld Channel %d %ld ***value out of range\n", i, num_of_samples, xchannels+1, signed_data_in_channel);
					}

					offset+=bytes_in_each_channel; // 2
				}
			}
			else 
			{
				am_util_stdio_printf("Reading chunk_header Error.\n");
				return ERR;
			}
		}

		return GOODEC;
}
/******************************************************************************/
/*                                                                            */
/* seconds_to_time                                                            */
/*                                                                            */
/******************************************************************************/
char* seconds_to_time(float raw_seconds, char* hms) 
{
		//
		// Convert seconds into hh:mm:ss:ms format
		//
		int hours, hours_residue, minutes, seconds, milliseconds;

		sprintf((char*)hms, (const char*)"%f", raw_seconds);

		hours = (int) raw_seconds/3600;
		hours_residue = (int) raw_seconds % 3600;
		minutes = hours_residue/60;
		seconds = hours_residue % 60;
		milliseconds = 0;

		char *pos;
		pos = strchr(hms, '.');
		int ipos = (int) (pos - hms);
		char decimalpart[15];
		memset(decimalpart, ' ', sizeof(decimalpart));
		strncpy(decimalpart, &hms[ipos+1], 3);
		milliseconds = atoi(decimalpart);	
		sprintf(hms, "%d:%d:%d.%d", hours, minutes, seconds, milliseconds);
		return hms;
}
/******************************************************************************/
/*                                                                            */
/* openwave                                                                   */
/*                                                                            */
/******************************************************************************/
int openwave(FIL *pFile)
{
		WAVE_HEADER header;
		uint32_t read_cnt;
		uint8_t data_buffer[4]; // 4=size_of_each_sample
		uint32_t redundent;

		f_read(pFile, (uint8_t*)&header, sizeof(header), (UINT*)&read_cnt);
		uint32_t num_of_samples=(8*header.data_size)/(header.channels*header.bits_per_sample);
		uint32_t size_of_each_sample=(header.channels*header.bits_per_sample)/8; // 4
		uint32_t bytes_in_each_channel=(size_of_each_sample/header.channels); // 4/2=2
		float duration_in_seconds=(float) header.overall_size/header.byterate;

		#if OPENWAVE_PRINT
		am_util_stdio_printf("(1-4): RIFF= %c%c%c%c\n", header.riff[0], header.riff[1], header.riff[2], header.riff[3]);
		am_util_stdio_printf("(5-8): Overall size= %ld bytes\n", header.overall_size);
		am_util_stdio_printf("(9-12): Wave marker= %c%c%c%c\n", header.wave[0], header.wave[1], header.wave[2], header.wave[3]);
		am_util_stdio_printf("(13-16): Fmt marker= %c%c%c%c\n", header.fmt_chunk_marker[0], header.fmt_chunk_marker[1], header.fmt_chunk_marker[2], header.fmt_chunk_marker[3]);
		am_util_stdio_printf("(17-20): Length of Fmt header= %ld\n", header.length_of_fmt);
		am_util_stdio_printf("(21-22): Format type= %d, ", header.format_type);
		switch(header.format_type)
		{
			case 1: am_util_stdio_printf("PCM\n"); break;
			case 6: am_util_stdio_printf("A-law\n"); break;
			case 7: am_util_stdio_printf("Mu-law\n"); break;
		}
		am_util_stdio_printf("(23-24): Channels= %d\n", header.channels);
		am_util_stdio_printf("(25-28): Sample rate= %ld\n", header.sample_rate);
		am_util_stdio_printf("(29-32): Byte Rate= %ld, Bit Rate= %ld\n", header.byterate, header.byterate*8);
		am_util_stdio_printf("(33-34): Block Alignment= %d\n", header.block_align);
		am_util_stdio_printf("(35-36): Bits per sample: %d\n", header.bits_per_sample);
		am_util_stdio_printf("(37-40): Data Marker= %c%c%c%c\n", header.data_chunk_header[0], header.data_chunk_header[1], header.data_chunk_header[2], header.data_chunk_header[3]); // LIST
		am_util_stdio_printf("(41-44): Size of data chunk= %ld\n", header.data_size); // 26
		am_util_stdio_printf("Number of samples= %ld\n", num_of_samples); // 6.5, 26=4*6+2
		am_util_stdio_printf("Size of each sample= %ld bytes\n", size_of_each_sample);
		am_util_stdio_printf("Approx.Duration in seconds=%f\n", duration_in_seconds);
		char hms[32];
		am_util_stdio_printf("Approx.Duration in h:m:s=%s\n", seconds_to_time(duration_in_seconds, hms));
		#endif

		if(header.format_type!=1) // PCM
		{
			am_util_stdio_printf("It is not PCM Data Format\n");
			return ERR;
		}
		#if OPENWAVE_PRINT
		am_util_stdio_printf("It is PCM Data Format\n");
		#endif

		if((bytes_in_each_channel*header.channels)!=size_of_each_sample) // 2*2=4
		{
			am_util_stdio_printf("Error: %ld x %ld != %ld\n", bytes_in_each_channel, header.channels, size_of_each_sample);
			return ERR;
		}
		#if OPENWAVE_PRINT
		am_util_stdio_printf("OK: %ld x %ld = %ld\n", bytes_in_each_channel, header.channels, size_of_each_sample);
		#endif

		#if OPENWAVE_PRINT
		int32_t low_limit;
		int32_t high_limit;
		switch (header.bits_per_sample) 
		{
			case 8:
						low_limit=-128; // -0x80
						high_limit=127; // 0x80-1
						break;
			case 16:
						low_limit=-32768; // -0x8000
						high_limit=32767; // 0x8000-1
						break;
			case 32:
						low_limit=-2147483648; // -0x80000000
						high_limit=2147483647; // 0x80000000-1
						break;
			default:
						low_limit=-1;
						high_limit=1;
						break;
		}
		am_util_stdio_printf("bits_per_sample = %d, low_limit = %d, high_limit = %d\n", header.bits_per_sample, low_limit, high_limit);
		#endif

		print_each_chunk_header(pFile, header);

		redundent=header.data_size-bytes_in_each_channel*header.channels*num_of_samples;
		f_read(pFile, data_buffer, redundent, (UINT*)&read_cnt); // 2 Bytes
		#if OPENWAVE_PRINT
		am_util_stdio_printf("redundent bytes=%d, byte[0]=%02X, byte[1]=%02X\n", redundent, data_buffer[0], data_buffer[1]);
		#endif

		return GOODEC;
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/









