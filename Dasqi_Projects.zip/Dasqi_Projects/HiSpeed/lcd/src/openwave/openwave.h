








#ifndef _OPENWAVE_H
#define _OPENWAVE_H
/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\main.h"
#include "..\FatFs\ff.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
#define ERR -1
#define GOODEC 0
/******************************************************************************/
#define OPENWAVE_PRINT 0
/******************************************************************************/
typedef struct _WAVE_HEADER 
{
		uint8_t riff[4];                // RIFF string, 4
		uint32_t overall_size	;         // overall size of file in bytes, 4
		uint8_t wave[4];                // WAVE string, 4
		uint8_t fmt_chunk_marker[4];    // fmt string with trailing null char, 4
		uint32_t length_of_fmt;         // length of the format header, 4
		uint16_t format_type;           // format type. 1-PCM, 3- IEEE float, 6 - 8bit A law, 7 - 8bit mu law, 2
		uint16_t channels;              // no.of channels, 2
		uint32_t sample_rate;           // sampling rate (blocks per second), 4
		uint32_t byterate;              // SampleRate * NumChannels * BitsPerSample/8, 4
		uint16_t block_align;           // NumChannels * BitsPerSample/8, 2
		uint16_t bits_per_sample;       // bits per sample, 8- 8bits, 16- 16 bits etc, 2
		uint8_t data_chunk_header[4];   // DATA string or FLLR string, 4
		uint32_t data_size;             // NumSamples * NumChannels * BitsPerSample/8 - size of the next chunk that will be read, 4
} WAVE_HEADER;
/******************************************************************************/
extern int print_each_chunk_header(FIL *pFile, WAVE_HEADER header);
extern char* seconds_to_time(float raw_seconds, char* hms);
extern int openwave(FIL *pFile);
/******************************************************************************/
#endif









