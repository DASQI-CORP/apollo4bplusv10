





/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "sdcard_file_test.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
FRESULT res;
FATFS eMMCFatFs;
FIL TestFile;
char eMMCPath[4];
/******************************************************************************/
//
// Check whether read data match with write data.
//
/******************************************************************************/
void check_if_rwbuf_match(uint8_t *rdbuf, uint8_t *wrbuf, uint32_t len)
{
		int i;
		for ( i = 0; i < len; i++ )
		{
				if (*(wrbuf + i) != *(rdbuf + i) )
				{
						am_util_stdio_printf("Test Fail: read and write buffer does not match from %d\n", i);
						break;
				}
		}
		
		if (i == len)
		{
				am_util_stdio_printf("\nRead write data matched!\neMMC FatFs Test Pass\n");
		}
}
/******************************************************************************/
/*                                                                            */
/* FatFs Read Write Test                                                      */
/*                                                                            */
/******************************************************************************/
void file_rw_test(void)
{
		uint8_t write_buf[256] = "This is the content insided the TXT\nApollo4 eMMC File System Example!!!\n";
		//
		// Print the banner.
		//
		am_util_stdio_printf("\nApollo4 eMMC FatFs example\n");
		//
		// Mount Disk
		//
		#if 1
		res = f_mount(&eMMCFatFs, (TCHAR const*)eMMCPath, 0);
		if(res!=FR_OK){am_util_stdio_printf("FatFs Initialization Fail\n"); while(1);}
		am_util_stdio_printf("FatFs is initialized\n");
		#endif
		//
		// Make File System
		//
		#if 0
		uint8_t work_buf[FF_MAX_SS];
		res=f_mkfs((TCHAR const*)eMMCPath, 0, work_buf, sizeof(work_buf));
		if(res!=FR_OK){am_util_stdio_printf("FatFs Format Fail\n"); while(1);}
		am_util_stdio_printf("FatFs Format OK\n");
		#endif
		//
		// Open Write Close
		//
		#if 1
		res=f_open(&TestFile, "FatFs.TXT", FA_CREATE_ALWAYS | FA_WRITE);
		if(res!=FR_OK){am_util_stdio_printf("Fail to open file for write\n"); while(1);}
		am_util_stdio_printf("File FatFs.TXT is opened for write\n");
		uint32_t write_cnt;
		res=f_write(&TestFile, write_buf, sizeof(write_buf), (void *)&write_cnt);
		if((res!=FR_OK)||(write_cnt==0)){ am_util_stdio_printf("File Write Error!\n"); while(1);}
		am_util_stdio_printf("File Write Success\n");
		res=f_close(&TestFile);
		if(res!=FR_OK){ am_util_stdio_printf("Fail to close file\n"); while(1); }
		am_util_stdio_printf("File is closed\n");
		#endif
		//
		// Open Read Close
		//
		#if 1
		res=f_open(&TestFile, "FatFs.TXT", FA_READ);
		if(res!=FR_OK){am_util_stdio_printf("Fail to open file for read\n"); while(1);}
		am_util_stdio_printf("File FatFs.TXT is opened for read\n");
		uint8_t read_buf[256];
		uint32_t read_cnt;
		res=f_read(&TestFile, read_buf, sizeof(read_buf), (UINT*)&read_cnt);
		if((res!=FR_OK)||(read_cnt==0)){am_util_stdio_printf("File Read Error!\n"); while(1);}
		am_util_stdio_printf("Read file success\n");
		res=f_close(&TestFile);
		if(res!=FR_OK){am_util_stdio_printf("Fail to close file\n"); while(1);}
		am_util_stdio_printf("Close file OK\n");
		#endif
		//
		// check_if_rwbuf_match.
		//
		#if 1
		check_if_rwbuf_match(read_buf, write_buf, sizeof(write_buf));
		#endif
		//
		// End banner.
		//
		am_util_stdio_printf("\nApollo4 eMMC FatFs example complete\n");
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/












