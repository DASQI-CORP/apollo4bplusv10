





/******************************************************************************/
/*                                                                            */
/* Includes                                                                   */
/*                                                                            */
/******************************************************************************/
#include "chsc6413.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/

/******************************************************************************/
/*                                                                            */
/* chsc6413_read buffer                                                         */
/*                                                                            */
/******************************************************************************/
int chsc6413_read(uint8_t addr, uint8_t *buffer, uint16_t length)
{
		int ret;

		if(buffer==NULL)
		{
			return DEVICES_I2C_STATUS_ERROR;
		}

		i2c_msg_t msgs[]=
		{
			{
				.addr   = CHSC6413_DEFAULT_ADDRESS,
				.flags  = AM_DEVICES_I2C_WR,
				.len    = 1,
				.buf    = &addr,
			},
			{
				.addr   = CHSC6413_DEFAULT_ADDRESS,
				.flags  = AM_DEVICES_I2C_RD,
				.len    = length,
				.buf    = buffer,
			},
		};

		ret=i2c_master_xfer(g_i2c0_IOMHandle, msgs, 2);
		
		if(ret==(msgs[0].len+msgs[1].len))
		{
			return DEVICES_I2C_STATUS_SUCCESS;
		}
		return DEVICES_I2C_STATUS_ERROR;
}
/******************************************************************************/
/*                                                                            */
/* chsc6413_write buffer                                                      */
/*                                                                            */
/******************************************************************************/
int chsc6413_write(uint8_t addr, uint8_t *buffer, uint16_t length)
{
		if(buffer==NULL)
		{
			return DEVICES_I2C_STATUS_ERROR;
		}

		uint8_t send_buffer[64];
		send_buffer[0]=addr;
		if(length>(sizeof(send_buffer)-1))return DEVICES_I2C_STATUS_ERROR;
		memcpy(send_buffer+1, buffer, length);

		i2c_msg_t msgs[] =
		{
			{
				.addr   = CHSC6413_DEFAULT_ADDRESS,
				.flags  = AM_DEVICES_I2C_WR,
				.len    = 1+length,
				.buf    = send_buffer,
			}
		};
		
		if(i2c_master_xfer(g_i2c0_IOMHandle, msgs, 1)==msgs->len)
		{
			return DEVICES_I2C_STATUS_SUCCESS;
		}
		else
		{
			return DEVICES_I2C_STATUS_ERROR;
		}
}
/******************************************************************************/
/*                                                                            */
/* chsc6413 write register                                                      */
/*                                                                            */
/******************************************************************************/
int chsc6413_writeRegister(uint8_t reg, uint8_t value)
{
		return chsc6413_write(reg, &value, 1);
}
/******************************************************************************/
/*                                                                            */
/* chsc6413 read register                                                       */
/*                                                                            */
/******************************************************************************/
uint8_t chsc6413_readRegister(uint8_t reg)
{
		uint8_t data[1];
		chsc6413_read(reg, data, sizeof(data));
		return data[0];
}
/******************************************************************************/
/*                                                                            */
/* chsc6413 read continue                                                     */
/*                                                                            */
/******************************************************************************/
int chsc6413_read_continue(uint8_t *buffer, uint16_t length)
{
		int ret;

		if(buffer==NULL)
		{
			return DEVICES_I2C_STATUS_ERROR;
		}

		i2c_msg_t msgs[]=
		{
			{
				.addr   = CHSC6413_DEFAULT_ADDRESS,
				.flags  = AM_DEVICES_I2C_RD,
				.len    = length,
				.buf    = buffer,
			},
		};

		ret=i2c_master_xfer(g_i2c0_IOMHandle, msgs, 1);
		
		if(ret==msgs[0].len)
		{
			return DEVICES_I2C_STATUS_SUCCESS;
		}
		return DEVICES_I2C_STATUS_ERROR;
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/







