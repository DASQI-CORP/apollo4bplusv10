





/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "touch.h"
#include "..\chsc6413\chsc6413.h"
#include "..\i2c\i2c.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable                                                            */
/*                                                                            */
/******************************************************************************/
void *g_i2c0_IOMHandle;
Touch_T touch;
/******************************************************************************/
/*                                                                            */
/* Init Touch                                                                 */
/*                                                                            */
/******************************************************************************/
void init_touch(void)
{
			//
			// Set TOUCH_RESET Pin Hi
			//
			am_hal_gpio_pinconfig(TOUCH_RST_PIN, am_hal_gpio_pincfg_output);
			am_hal_gpio_state_write(TOUCH_RST_PIN, AM_HAL_GPIO_OUTPUT_TRISTATE_DISABLE);
			am_hal_gpio_state_write(TOUCH_RST_PIN, AM_HAL_GPIO_OUTPUT_SET);
			//
			// Reset Touch
			//
			am_util_delay_ms(1);
			am_hal_gpio_state_write(TOUCH_RST_PIN, AM_HAL_GPIO_OUTPUT_CLEAR);
			am_util_delay_ms(1);
			am_hal_gpio_state_write(TOUCH_RST_PIN, AM_HAL_GPIO_OUTPUT_SET);
			am_util_delay_ms(6);

			i2c_init(I2C_MODULE_0, &g_i2c_Cfg, &g_i2c0_IOMHandle);

			uint8_t data[3]={0};
			chsc6413_read(0x00, data, sizeof(data));
}
/******************************************************************************/
/*                                                                            */
/* scan_touch_pad                                                             */
/*                                                                            */
/******************************************************************************/
void scan_touch_pad(void)
{
		uint8_t data[3]={0};
		if(chsc6413_read_continue(data, sizeof(data))==DEVICES_I2C_STATUS_ERROR)return;

		if((data[0]&0x03)==0x01) 
		{
			touch.bTouch=true;
			if((data[0]&0x40)==0x40)touch.x=256;else touch.x=0;
			if((data[0]&0x80)==0x80)touch.y=256;else touch.y=0;
			touch.x+=data[1];
			touch.y+=data[2];

			touch.x=511-touch.x;
			touch.y=511-touch.y;
		}
		else
		{
			touch.bTouch=false;
		}

		#if 0 // Monitor Touch
		if(touch.bTouch)
		{
			am_util_stdio_printf("Touch=TRUE, x=%u, y=%u\n", touch.x, touch.y);
			toggle_led(nLED0);
		}
		else
		{
			am_hal_gpio_state_write(nLED0, AM_HAL_GPIO_OUTPUT_SET); // Turn Off nLED0
		}
		#endif
}
/******************************************************************************/
/*                                                                            */
/* Task Touch                                                                 */
/*                                                                            */
/******************************************************************************/
void TASK_Touch(void)
{
		static bool init=false;
		static uint32_t t0;


		if(!init)
		{
			t0=msec;
			init=true;
			init_touch();
		}
		else
		{
			if((msec-t0)>9)
			{
				t0=msec;
				scan_touch_pad();
			}
		}
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/





