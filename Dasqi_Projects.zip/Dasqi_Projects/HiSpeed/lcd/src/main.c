






/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "main.h"
/******************************************************************************/
#include "nema_graphics.h"
#include "nema_dc.h"
/******************************************************************************/
#include "FreeRTOS.h"
#include "rtos.h"
/******************************************************************************/
/*                                                                            */
/* Global Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
uint32_t SystemCoreClock = 96000000UL;
/******************************************************************************/
/*                                                                            */
/* toggle_led                                                                 */
/*                                                                            */
/******************************************************************************/
void toggle_led(uint8_t led)
{
		if(am_hal_gpio_output_read(led))
		{
			am_hal_gpio_state_write(led, AM_HAL_GPIO_OUTPUT_CLEAR);
		}
		else
		{
			am_hal_gpio_state_write(led, AM_HAL_GPIO_OUTPUT_SET);
		}
}
/******************************************************************************/
/*                                                                            */
/* TASK_SYS                                                                   */
/*                                                                            */
/******************************************************************************/
void TASK_SYS(void)
{
		static bool init=true;
		static uint32_t t0;

		if(init)
		{
			init=false;
			t0=msec;
		}
		else
		{
			if((msec-t0)>999)
			{
				t0=msec;
				toggle_led(nLED0);
			}
		}
}
/******************************************************************************/
/*                                                                            */
/* setup                                                                      */
/*                                                                            */
/******************************************************************************/
void setup(void)
{
		//
		// IO Setup
		//
		am_hal_gpio_pinconfig(VDD_USB_33_EN, am_hal_gpio_pincfg_output);
		am_hal_gpio_state_write(VDD_USB_33_EN, AM_HAL_GPIO_OUTPUT_TRISTATE_DISABLE);
		am_hal_gpio_state_write(VDD_USB_33_EN, AM_HAL_GPIO_OUTPUT_SET);

		am_hal_gpio_pinconfig(VDD18_EN, am_hal_gpio_pincfg_output);
		am_hal_gpio_state_write(VDD18_EN, AM_HAL_GPIO_OUTPUT_TRISTATE_DISABLE);
		am_hal_gpio_state_write(VDD18_EN, AM_HAL_GPIO_OUTPUT_SET);

		am_hal_gpio_pinconfig(VDD_USB_0P9_EN, am_hal_gpio_pincfg_output);
		am_hal_gpio_state_write(VDD_USB_0P9_EN, AM_HAL_GPIO_OUTPUT_TRISTATE_DISABLE);
		am_hal_gpio_state_write(VDD_USB_0P9_EN, AM_HAL_GPIO_OUTPUT_SET);

		am_hal_gpio_pinconfig(nLED0, am_hal_gpio_pincfg_output); // LED0
		am_hal_gpio_state_write(nLED0, AM_HAL_GPIO_OUTPUT_TRISTATE_DISABLE);
		am_hal_gpio_state_write(nLED0, AM_HAL_GPIO_OUTPUT_SET);
		//
		// Configure the board for low power.
		//
		am_bsp_low_power_init();
		//
		// Global interrupt enable.
		//
		am_hal_interrupt_master_enable();
		//
		// Enable printing to the console.
		//
		am_bsp_itm_printf_enable();
		//
		// Initial STIMER
		//
		stimer_init();

		#if 1
		am_hal_pwrctrl_dsp_memory_config_t sExtSRAMMemCfg =
		{
			.bEnableICache      = false,
			.bRetainCache       = false,
			.bEnableRAM         = true,
			.bActiveRAM         = false,
			.bRetainRAM         = true
		};
		#if 0 // for Reference
		am_hal_pwrctrl_mcu_memory_config(&sMcuMemCfg);
		am_hal_pwrctrl_sram_config(&sSRAMMemCfg); //!< 0.2mA
		#endif
		am_hal_pwrctrl_dsp_memory_config(AM_HAL_DSP0, &sExtSRAMMemCfg);
		am_hal_pwrctrl_dsp_memory_config(AM_HAL_DSP1, &sExtSRAMMemCfg);
		//
		// Enable Peripherial Power
		//
		am_hal_pwrctrl_periph_enable(AM_HAL_PWRCTRL_PERIPH_GFX);
		#if 0 // for Reference
		am_hal_pwrctrl_periph_enable(AM_HAL_PWRCTRL_PERIPH_SDIO);
		am_hal_pwrctrl_periph_enable(AM_HAL_PWRCTRL_PERIPH_MSPI2);
		am_hal_pwrctrl_periph_enable(AM_HAL_PWRCTRL_PERIPH_DISP);
		#endif
		//
		// SETUP BURST_MODE
		//
		am_hal_pwrctrl_mcu_mode_select(AM_HAL_PWRCTRL_MCU_MODE_HIGH_PERFORMANCE);
		//
		// Enable Cache Control
		//
		am_hal_cachectrl_config(&am_hal_cachectrl_defaults);
		am_hal_cachectrl_enable();
		//
		// Disable crypto
		//
		am_hal_pwrctrl_periph_disable(AM_HAL_PWRCTRL_PERIPH_CRYPTO);
		#endif

		//
		// DSI_QSPI Power Up
		//
		#ifdef USE_NEMADC
		//
		// AM_HAL_CLKGEN_CONTROL_DISPCLKSEL_HFRC48=24MHz
		// AM_HAL_CLKGEN_CONTROL_DISPCLKSEL_HFRC96=48MHz
		//
		am_hal_clkgen_control(AM_HAL_CLKGEN_CONTROL_DISPCLKSEL_HFRC96, NULL);
		am_hal_clkgen_control(AM_HAL_CLKGEN_CONTROL_DCCLK_ENABLE, NULL);
		am_hal_pwrctrl_periph_enable(AM_HAL_PWRCTRL_PERIPH_GFX);
		am_hal_pwrctrl_periph_enable(AM_HAL_PWRCTRL_PERIPH_DISP);
		#endif
		//
		// Start
		//
		am_util_stdio_printf("Start .......\n");
}
/******************************************************************************/
/*                                                                            */
/* Main Function                                                              */
/*                                                                            */
/******************************************************************************/
int main(void)
{
		//
		// Set Up
		//
		setup();
		//
		// loop forever
		//
		run_tasks();
		//
		// We shouldn't ever get here.
		//
		while (1){}
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
