


#ifndef _SDCARD_SDIO_H
#define _SDCARD_SDIO_H
/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\main.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
#define SDCARD_SDIO_PRINT 0
/******************************************************************************/
extern am_hal_card_t eMMCard;
extern am_hal_card_host_t *pSdhcCardHost;
extern uint32_t MaxSectors;
/******************************************************************************/
/*                                                                            */
/* Functions                                                                  */
/*                                                                            */
/******************************************************************************/
extern void print_cmd(am_hal_card_cmd_t cmd);
extern uint32_t am_hal_sdmmc_cmd0_go_idle(am_hal_card_t *pCard);
extern uint32_t am_hal_sdmmc_cmd2_send_cid(am_hal_card_t *pCard);
extern uint32_t am_hal_sdmmc_cmd3_set_rca(am_hal_card_t *pCard, uint16_t ui16RCA);
extern uint32_t am_hal_sdmmc_cmd7_card_select(am_hal_card_t *pCard);
extern uint32_t _am_hal_card_mode_switch(am_hal_card_t *pCard, uint32_t ui32Mode, uint32_t ui32Timeout);
extern uint32_t _am_hal_card_block_read_async(am_hal_card_t *pCard, uint32_t ui32Blk, uint32_t ui32BlkCnt, uint8_t *pui8Buf);
extern uint32_t _am_hal_card_block_write_async(am_hal_card_t *pCard, uint32_t ui32Blk, uint32_t ui32BlkCnt, uint8_t *pui8Buf);
extern uint32_t _am_hal_card_host_find_card(am_hal_card_host_t *pHost, am_hal_card_t *pCard);
extern uint32_t _am_hal_card_init(am_hal_card_t *pCard, am_hal_card_pwr_ctrl_func pCardPwrCtrlFunc, am_hal_card_pwr_ctrl_policy_e eCardPwrCtrlPolicy);
extern uint32_t _am_hal_card_status(am_hal_card_t *pCard, uint32_t *pui32Status);
/******************************************************************************/
#endif


