


/******************************************************************************/
/*                                                                            */
/* Include                                                                    */
/*                                                                            */
/******************************************************************************/
#include "..\sdcard\sdcard.h"
#include "sdcard_sdio.h"
/******************************************************************************/
/*                                                                            */
/* Globle Variable and Defines                                                */
/*                                                                            */
/******************************************************************************/
am_hal_card_t eMMCard;
am_hal_card_host_t *pSdhcCardHost = NULL;
uint32_t MaxSectors;
/******************************************************************************/
/*                                                                            */
/* print cmd                                                                  */
/*                                                                            */
/******************************************************************************/
void print_cmd(am_hal_card_cmd_t cmd)
{
		#if SDCARD_SDIO_PRINT
		am_util_stdio_printf("CMD%2d-0x%08X-", cmd.ui8Idx, cmd.ui32Arg);
		for(int i=0; i<4; i++)am_util_stdio_printf("%08X ", cmd.ui32Resp[i]);
		am_util_stdio_printf("\n");
		#endif
}
/******************************************************************************/
/*                                                                            */
/* Set Speed                                                                  */
/*                                                                            */
/******************************************************************************/
uint32_t am_hal_card_set_speed(am_hal_card_t *pCard, uint32_t ui32Clock)
{
		am_hal_card_host_t *pHost=pCard->pHost;

		if ( pHost->ops->set_bus_clock(pHost->pHandle, ui32Clock) != AM_HAL_STATUS_SUCCESS )
		{
				return AM_HAL_STATUS_FAIL;
		}
		
		return AM_HAL_STATUS_SUCCESS;
}
/******************************************************************************/
/*                                                                            */
/* CMD0 - go idle                                                             */
/*                                                                            */
/******************************************************************************/
uint32_t am_hal_sdmmc_cmd0_go_idle(am_hal_card_t *pCard)
{
		am_hal_card_cmd_t cmd;
		am_hal_card_host_t *pHost = pCard->pHost;

		memset(&cmd, 0, sizeof(cmd));
		cmd.ui8Idx   = MMC_CMD_GO_IDLE_STATE;
		cmd.ui32Arg  = 0x0;
		cmd.ui32RespType = MMC_RSP_NONE;
		pHost->ops->execute_cmd(pHost->pHandle, &cmd, NULL);
		print_cmd(cmd);
		return cmd.eError;
}
/******************************************************************************/
/*                                                                            */
/* CMD2 - Send Card Identification                                            */
/*                                                                            */
/******************************************************************************/
uint32_t am_hal_sdmmc_cmd2_send_cid(am_hal_card_t *pCard)
{
		am_hal_card_cmd_t cmd;
		am_hal_card_host_t *pHost = pCard->pHost;

		memset(&cmd, 0, sizeof(cmd));
		cmd.ui8Idx   = MMC_CMD_ALL_SEND_CID;
		cmd.ui32Arg  = 0x0;
		cmd.ui32RespType = MMC_RSP_R2;
		pHost->ops->execute_cmd(pHost->pHandle, &cmd, NULL);
		if ( cmd.eError == AM_HAL_CMD_ERR_NONE )
		{
			memcpy((void *)pCard->ui32CID, (void *)&cmd.ui32Resp[0], 16);
			pCard->bCidValid = 1;
		}
		print_cmd(cmd);
		return cmd.eError;
}
/******************************************************************************/
/*                                                                            */
/* CMD3 - Send the Relative Card Address                                      */
/*                                                                            */
/******************************************************************************/
uint32_t am_hal_sdmmc_cmd3_set_rca(am_hal_card_t *pCard, uint16_t ui16RCA)
{
		am_hal_card_cmd_t cmd;
		am_hal_card_host_t *pHost = pCard->pHost;

		memset(&cmd, 0, sizeof(cmd));
		cmd.ui8Idx   = MMC_CMD_SET_RELATIVE_ADDR;
		cmd.ui32Arg  = ui16RCA << 16;
		cmd.ui32RespType = MMC_RSP_R6;
		pHost->ops->execute_cmd(pHost->pHandle, &cmd, NULL);
		if ( cmd.eError == AM_HAL_CMD_ERR_NONE )
		{
			pCard->ui16RCA = (cmd.ui32Resp[0]>>16)&0x0000FFFF;
		}
		print_cmd(cmd);
		return cmd.eError;
}
/******************************************************************************/
/*                                                                            */
/* CMD6 - Set Bus Width 4                                                     */
/*                                                                            */
/******************************************************************************/
uint32_t am_hal_sdmmc_cmd6_set_bus_width_4(am_hal_card_t *pCard)
{
		am_hal_card_cmd_t cmd;
		am_hal_card_host_t *pHost = pCard->pHost;

		memset(&cmd, 0x0, sizeof(cmd));
		cmd.ui8Idx   = MMC_CMD_SWITCH;
		cmd.ui32Arg  = (1<<8); // 0x00000002; // MMC_EXT_MODE_WRITE_BYTE(0x11<<24) | MMC_EXT_REGS_BUS_WIDTH(183<<16) | MMC_EXT_SET_BUS_WIDTH4(1<<8);
		cmd.ui32RespType = MMC_RSP_R1;
		pHost->ops->execute_cmd(pHost->pHandle, &cmd, NULL);
		print_cmd(cmd);
		return cmd.eError;
}
/******************************************************************************/
/*                                                                            */
/* CMD7 - Select the Card                                                     */
/*                                                                            */
/******************************************************************************/
uint32_t am_hal_sdmmc_cmd7_card_select(am_hal_card_t *pCard)
{
		am_hal_card_cmd_t cmd;
		am_hal_card_host_t *pHost = pCard->pHost;

		memset(&cmd, 0, sizeof(cmd));
		cmd.ui8Idx   = MMC_CMD_SELECT_CARD;
		cmd.ui32Arg  = pCard->ui16RCA << 16;

		//
		// RCA of zero is not valid for a card select, so this
		// is a card deselect which requires no response
		//
		if ( pCard->ui16RCA == 0x0 )
		{
			cmd.ui32RespType = MMC_RSP_NONE;
		}
		else
		{
			cmd.ui32RespType = MMC_RSP_R1;
		}

		pHost->ops->execute_cmd(pHost->pHandle, &cmd, NULL);

		if ( cmd.eError == AM_HAL_CMD_ERR_NONE )
	{
		//
		// For a card deselect, the state is stand-by-state
		//
		if ( pCard->ui16RCA == 0x0 )
		{
			pCard->eState = AM_HAL_CARD_STATE_STDY;
		}
		//
		// for a card select, the state is the transfer state
		//
		else
		{
			pCard->eState = AM_HAL_CARD_STATE_TRANS;
		}
		}
		print_cmd(cmd);
		return cmd.eError;
}
/******************************************************************************/
/*                                                                            */
/* CMD8 - Send IF Condition                                                   */
/*                                                                            */
/******************************************************************************/
uint32_t am_hal_sdmmc_cmd8_send_if_cond(am_hal_card_t *pCard)
{
		am_hal_card_cmd_t cmd;
		am_hal_card_host_t *pHost = pCard->pHost;

		memset(&cmd, 0x0, sizeof(cmd));
		cmd.ui8Idx   = MMC_CMD_SEND_EXT_CSD;
		cmd.ui32Arg  = 0x000001AA;
		cmd.ui32RespType = MMC_RSP_R7;
		pHost->ops->execute_cmd(pHost->pHandle, &cmd, NULL);
		print_cmd(cmd);
		return cmd.eError;
}
/******************************************************************************/
/*                                                                            */
/* CMD9 - get the CSD                                                         */
/*                                                                            */
/******************************************************************************/
uint32_t am_hal_sdmmc_cmd9_send_csd(am_hal_card_t *pCard)
{
		am_hal_card_cmd_t cmd;
		am_hal_card_host_t *pHost = pCard->pHost;

		memset(&cmd, 0, sizeof(cmd));
		cmd.ui8Idx   = MMC_CMD_SEND_CSD;
		cmd.ui32Arg  = pCard->ui16RCA << 16;
		cmd.ui32RespType = MMC_RSP_R2;
		pHost->ops->execute_cmd(pHost->pHandle, &cmd, NULL);
		if ( cmd.eError == AM_HAL_CMD_ERR_NONE )
		{
			memcpy((void *)pCard->ui32CSD, (void *)&cmd.ui32Resp[0], 16);
			pCard->bCsdValid = 1;
		}
		print_cmd(cmd);
		
		uint8_t m=(uint8_t)((cmd.ui32Resp[1]>>16)&0x0000000F);
		uint8_t n=(uint8_t)(cmd.ui32Resp[1]&0x0000003F);
		uint32_t c_size=((cmd.ui32Resp[2]>>16)&0x0000FFFF)|(n<<16);

		pCard->ui32BlkSize=(0x01)<<m;;
		pCard->ui32MaxBlks=(c_size+1)*1024;
		pCard->ui32Capacity=pCard->ui32BlkSize*pCard->ui32MaxBlks;
		MaxSectors=pCard->ui32MaxBlks;

		#if SDCARD_SDIO_PRINT
		am_util_stdio_printf("pCard->ui32BlkSize=%d\n", pCard->ui32BlkSize);
		am_util_stdio_printf("c_size=0x%08X\n", c_size);
		am_util_stdio_printf("pCard->ui32MaxBlks=0x%08X\n", pCard->ui32MaxBlks);
		am_util_stdio_printf("pCard->ui32Capacity=0x%08X\n", pCard->ui32Capacity);
		#endif

		return cmd.eError;
}
/******************************************************************************/
/*                                                                            */
/* CMD41                                                                      */
/*                                                                            */
/******************************************************************************/
static uint32_t am_hal_sdmmc_cmd41(am_hal_card_t *pCard)
{
		am_hal_card_cmd_t cmd;
		am_hal_card_host_t *pHost = pCard->pHost;

		memset(&cmd, 0x0, sizeof(cmd));
		cmd.ui8Idx   = 41;
		cmd.ui32Arg  = 0xC0100000;
		cmd.ui32RespType = MMC_RSP_R3;
		pHost->ops->execute_cmd(pHost->pHandle, &cmd, NULL);
		print_cmd(cmd);
		if((cmd.ui32Resp[0]&0xFF000000)==0xC0000000)
		{
			pCard->eState=AM_HAL_CARD_STATE_READY;
			pCard->bHighCapcity=true;
			pCard->ui32OCR=cmd.ui32Resp[0];
		}
		else
		{
				cmd.eError=AM_HAL_CMD_ERR_INHIBIT;
		}
		return cmd.eError;
}
/******************************************************************************/
/*                                                                            */
/* CMD55                                                                      */
/*                                                                            */
/******************************************************************************/
static uint32_t am_hal_sdmmc_cmd55(am_hal_card_t *pCard)
{
		am_hal_card_cmd_t cmd;
		am_hal_card_host_t *pHost = pCard->pHost;

		memset(&cmd, 0x0, sizeof(cmd));
		cmd.ui8Idx   = MMC_CMD_APP_CMD;
		cmd.ui32Arg  = pCard->ui16RCA << 16;
		cmd.ui32RespType = MMC_RSP_R1;
		pHost->ops->execute_cmd(pHost->pHandle, &cmd, NULL);
		print_cmd(cmd);
		return cmd.eError;
}
/******************************************************************************/
/*                                                                            */
/* am_hal_card_mmc_init()                                                     */
/*                                                                            */
/******************************************************************************/
static uint32_t am_hal_card_mmc_init(am_hal_card_t *pCard)
{
		#if SDCARD_SDIO_PRINT
		am_util_stdio_printf("am_hal_card.c am_hal_card_mmc_init();\n");
		#endif

		/*--------------------------------------------------*/
		/*                                                  */
		/* CMD0 Reset the card                              */
		/*                                                  */
		/*--------------------------------------------------*/
		if ( am_hal_sdmmc_cmd0_go_idle(pCard) != AM_HAL_CMD_ERR_NONE )
		{
				am_util_stdio_printf("CMD0 Failed\n");
				return AM_HAL_STATUS_FAIL;
		}
		/*--------------------------------------------------*/
		/*                                                  */
		/* CMD8 Send IF Condition                           */
		/*                                                  */
		/*--------------------------------------------------*/
		if ( am_hal_sdmmc_cmd8_send_if_cond(pCard) != AM_HAL_CMD_ERR_NONE )
		{
			am_util_stdio_printf("CMD8 Failed\n");
			return AM_HAL_STATUS_FAIL;
		}
		pCard->eType = AM_HAL_CARD_TYPE_EMMC; // Should be AM_HAL_CARD_TYPE_SDHC
		/*--------------------------------------------------*/
		/*                                                  */
		/* ACMD41                                           */
		/*                                                  */
		/*--------------------------------------------------*/
		uint32_t TO=3;
		do
		{
			if ( am_hal_sdmmc_cmd55(pCard) != AM_HAL_CMD_ERR_NONE )
			{
				am_util_stdio_printf("CMD55 Failed\n");
				return AM_HAL_STATUS_FAIL;
			}
			if ( am_hal_sdmmc_cmd41(pCard) != AM_HAL_CMD_ERR_NONE )
			{
				#if SDCARD_SDIO_PRINT
				am_util_stdio_printf("CMD41 Failed\n");
				#endif
			}
			else
			{
				break;
			}
			am_util_delay_ms(10);
		}while(--TO);
		/*--------------------------------------------------*/
		/*                                                  */
		/* CMD2 Get the CID information of the card         */
		/*                                                  */
		/*--------------------------------------------------*/
		if ( am_hal_sdmmc_cmd2_send_cid(pCard) != AM_HAL_CMD_ERR_NONE )
		{
			am_util_stdio_printf("CMD2 Failed\n");
			return AM_HAL_STATUS_FAIL;
		}
		/*--------------------------------------------------*/
		/*                                                  */
		/* CMD3 Get relative card address                   */
		/*                                                  */
		/*--------------------------------------------------*/
		if ( am_hal_sdmmc_cmd3_set_rca(pCard, 0x0) != AM_HAL_CMD_ERR_NONE )
		{
			am_util_stdio_printf("CMD3 Failed\n");
			return AM_HAL_STATUS_FAIL;
		}
		/*--------------------------------------------------*/
		/*                                                  */
		/* CMD9 Get the card CSD                            */
		/*                                                  */
		/*--------------------------------------------------*/
		if ( am_hal_sdmmc_cmd9_send_csd(pCard) != AM_HAL_CMD_ERR_NONE )
		{
			am_util_stdio_printf("CMD9 Failed\n");
			return AM_HAL_STATUS_FAIL;
		}
		/*--------------------------------------------------*/
		/*                                                  */
		/* CMD7 Select the card                             */
		/*                                                  */
		/*--------------------------------------------------*/
		if ( am_hal_sdmmc_cmd7_card_select(pCard) != AM_HAL_CMD_ERR_NONE )
		{
			am_util_stdio_printf("CMD7 Failed\n");
			return AM_HAL_STATUS_FAIL;
		}
		/*--------------------------------------------------*/
		/*                                                  */
		/* ACMD6 Switch Bus to Width 4                      */
		/*                                                  */
		/*--------------------------------------------------*/
		#ifdef SDIO_WIDTH_4
		if ( am_hal_sdmmc_cmd55(pCard) != AM_HAL_CMD_ERR_NONE )
		{
			am_util_stdio_printf("CMD55 Failed\n");
			return AM_HAL_STATUS_FAIL;
		}
		if ( am_hal_sdmmc_cmd6_set_bus_width_4(pCard) != AM_HAL_CMD_ERR_NONE )
		{
			am_util_stdio_printf("CMD6 Failed\n");
			return AM_HAL_STATUS_FAIL;
		}
		#endif

		if(am_hal_card_set_speed(pCard, SDIO_BUS_SPEED)!=AM_HAL_STATUS_SUCCESS)
		{
			am_util_stdio_printf("Set Speed Failed\n");
			return AM_HAL_STATUS_FAIL;
		}

		return AM_HAL_STATUS_SUCCESS;
}
/******************************************************************************/
/*                                                                            */
/* Find Card                                                                  */
/*                                                                            */
/******************************************************************************/
uint32_t _am_hal_card_host_find_card(am_hal_card_host_t *pHost, am_hal_card_t *pCard)
{
		if ( pHost->bCardInSlot || pHost->ops->get_cd(pHost->pHandle) )
		{
			pCard->eState = AM_HAL_CARD_STATE_PRESENT;
			pCard->pHost  = pHost;
			//
			// Fill the default setting with the host's current value
			//
			pCard->cfg.eBusWidth = pHost->eBusWidth;
			pCard->cfg.eIoVoltage = pHost->eBusVoltage;
			pCard->cfg.ui32Clock = pHost->ui32MinClock;
			pCard->cfg.eUHSMode = pHost->eUHSMode;
			pCard->eState = AM_HAL_CARD_STATE_PWROFF;
			return AM_HAL_STATUS_SUCCESS;
		}
		else
		{
			pCard->eState = AM_HAL_CARD_STATE_NOT_PRESENT;
			return AM_HAL_STATUS_FAIL;
		}
}
/******************************************************************************/
/*                                                                            */
/* am_hal_card_init                                                           */
/*                                                                            */
/******************************************************************************/
uint32_t _am_hal_card_init(am_hal_card_t *pCard, am_hal_card_pwr_ctrl_func pCardPwrCtrlFunc, am_hal_card_pwr_ctrl_policy_e eCardPwrCtrlPolicy)
{
		#if SDCARD_SDIO_PRINT
		am_util_stdio_printf("am_hal_card_init()\n");
		#endif
		//
		// Check Connection
		//
		if(!pCard||!pCard->pHost )
		{
			am_util_stdio_printf("This card is not connected to a host\n");
			return AM_HAL_STATUS_INVALID_ARG;
		}
		//
		// Turn on the eMMC card power supply firstly
		//
		if (pCard->eState == AM_HAL_CARD_STATE_PWROFF && pCardPwrCtrlFunc != NULL)
		{
			am_util_stdio_printf("turn on the eMMC power supply\n");
			pCardPwrCtrlFunc(AM_HAL_CARD_PWR_ON);
		}

		pCard->pCardPwrCtrlFunc = pCardPwrCtrlFunc;
		pCard->eState = AM_HAL_CARD_STATE_PWRON;
		pCard->eCardPwrCtrlPolicy = eCardPwrCtrlPolicy;


		if(am_hal_card_mmc_init(pCard)!=AM_HAL_STATUS_SUCCESS)
		{
			return AM_HAL_STATUS_FAIL;
		}

		#if 0
		am_util_stdio_printf("card type is %d\n", pCard->eType);
		#endif

		return AM_HAL_STATUS_SUCCESS;
}
/******************************************************************************/
/*                                                                            */
/* Card Block Read Write                                                      */
/*                                                                            */
/******************************************************************************/
uint32_t am_hal_card_block_rw(am_hal_card_t *pCard, uint32_t ui32Blk, uint32_t ui32BlkCnt, uint8_t *pui8Buf, bool bRead, bool bASync)
{
		uint32_t ui32Status;

		am_hal_card_host_t *pHost;
		am_hal_card_cmd_t cmd;
		am_hal_card_cmd_data_t cmd_data;

		if ( pCard->eState != AM_HAL_CARD_STATE_TRANS )
		{
			return AM_HAL_STATUS_INVALID_OPERATION;
		}

		pHost = pCard->pHost;

		//
		// Check if the start block number and block count is valid or not
		//
		if ( ui32Blk >= pCard->ui32MaxBlks || (ui32BlkCnt > 0xFFFF) || (ui32Blk + ui32BlkCnt) > pCard->ui32MaxBlks )
		{
			return AM_HAL_STATUS_OUT_OF_RANGE;
		}

		if ( pHost->eXferMode == AM_HAL_HOST_XFER_ADMA && ui32BlkCnt > pHost->ui32MaxADMA2BlkNums )
		{
			ui32BlkCnt = pHost->ui32MaxADMA2BlkNums;
		}

		memset((void *)&cmd, 0x0, sizeof(cmd));
		memset((void *)&cmd_data, 0x0, sizeof(cmd_data));
		if ( bRead )
		{
			cmd.ui8Idx = ui32BlkCnt > 1 ? MMC_CMD_READ_MULTIPLE_BLOCK : MMC_CMD_READ_SINGLE_BLOCK;
		}
		else
		{
			cmd.ui8Idx = ui32BlkCnt > 1 ? MMC_CMD_WRITE_MULTIPLE_BLOCK : MMC_CMD_WRITE_SINGLE_BLOCK;
		}

		cmd.ui32Arg = pCard->bHighCapcity ? ui32Blk : ui32Blk * pCard->ui32BlkSize;
		cmd.ui32RespType = MMC_RSP_R1;
		cmd.bASync = bASync;


		cmd_data.pui8Buf = pui8Buf;
		cmd_data.ui32BlkCnt = ui32BlkCnt;
		cmd_data.ui32BlkSize = pCard->ui32BlkSize;
		cmd_data.dir = bRead ? AM_HAL_DATA_DIR_READ : AM_HAL_DATA_DIR_WRITE;

		if ( cmd.bASync )
		{
			pHost->AsyncCmd = cmd;
			pHost->AsyncCmdData = cmd_data;
		}

		ui32Status = pHost->ops->execute_cmd(pHost->pHandle, &cmd, &cmd_data);

		return ui32Status;
}
/******************************************************************************/
/*                                                                            */
/* Block Read Async                                                           */
/*                                                                            */
/******************************************************************************/
uint32_t _am_hal_card_block_read_async(am_hal_card_t *pCard, uint32_t ui32Blk, uint32_t ui32BlkCnt, uint8_t *pui8Buf)
{
		return am_hal_card_block_rw(pCard, ui32Blk, ui32BlkCnt, pui8Buf, true, true);
}
/******************************************************************************/
/*                                                                            */
/* Block Write Async                                                          */
/*                                                                            */
/******************************************************************************/
uint32_t _am_hal_card_block_write_async(am_hal_card_t *pCard, uint32_t ui32Blk, uint32_t ui32BlkCnt, uint8_t *pui8Buf)
{
		return am_hal_card_block_rw(pCard, ui32Blk, ui32BlkCnt, pui8Buf, false, true);
}
/******************************************************************************/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/


















